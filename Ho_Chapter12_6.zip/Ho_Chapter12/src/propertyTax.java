/*
 * Quang Ho
 * 11/9/2020
 * Chapter 12
 * Challenge 4
 * This set of code calculates the exact value the user has enter and display the property tax and assessment value
 * This calculation will be display on a GUI 
 */
public class propertyTax {
	//The assessment value is 60% of the actual value
	//The property tax will the value of the assessment value multiplied by the property tax
	//Set all values to double
	private double PROPERTY_TAX_RATE = 0.0064;
	private double ASSESSMENT_VALUE_RATE = 0.6;
	
	private double actualValue, assessmentValue, propertyTax;

	public propertyTax(double value)
	{
		setActualValue(value);
		calculateAssessmentValue();
		calculatePropertyTax();
	}
	

	

	private void setActualValue(double value)
	{
		actualValue = value;
	}
	

	private void calculateAssessmentValue()
	{
		assessmentValue = actualValue * ASSESSMENT_VALUE_RATE;
	}
	

	private void calculatePropertyTax()
	{
		propertyTax = assessmentValue * PROPERTY_TAX_RATE;
	}
	

	public double getActualValue()
	{
		return actualValue;
	}
	

	public double getAssessmentValue()
	{
		return assessmentValue;
	}
	
	

	public double getPropertyTax()
	{
		return propertyTax;
	}
}
