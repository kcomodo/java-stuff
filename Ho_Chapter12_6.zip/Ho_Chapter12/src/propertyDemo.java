/*
 * Main program to call out for the GUI
 */
public class propertyDemo {
	propertyTaxWindow window = new propertyTaxWindow();
}
