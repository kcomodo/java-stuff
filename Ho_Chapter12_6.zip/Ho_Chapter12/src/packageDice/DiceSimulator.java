package packageDice;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
/*
 * Quang Ho
 * 11/15/2020
 * Dice Simulator
 * Chapter 12
 * Exercise 6
 * Create a dice simulator displaying two dice when rolled
 * Based off of chapter 12 Dice simulator 
 */
public class DiceSimulator extends JFrame{
	//Set width and height of window
	private final int WINDOW_WIDTH = 300;
	private final int WINDOW_HEIGHT = 200;
	//Create two dice named die1 and die2
	//both dice requires a panel, label and imageicon
	private JPanel die1Panel;
	private JPanel die2Panel;
	private JPanel buttonPanel;
	private JLabel die1Label;
	private JLabel die2Label;
	private ImageIcon die1Image;
	private ImageIcon die2Image;
	private JButton button;
	private Container contentPane;
	//array list will store the dice images
	private ArrayList<ImageIcon> dieImageList;
	//Create the dice window
	public DiceSimulator() {
		//Set title
		setTitle("Dice Simulator");
		//Set the size
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
		//Window will close out
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		//Create the dieimagelist
		 buildDieImageList();
		 //Create the two dice panels
		 buildDie1Panel();
		 buildDie2Panel();
		 //Create the button panel
		 buildButtonPanel();
		 //Die1 will be on the left side and die2 will be on the right
		 //Button panel will be at the bottom
		 add(die1Panel,BorderLayout.WEST);
		 add(die2Panel,BorderLayout.EAST);
		 add(buttonPanel, BorderLayout.SOUTH);
		 //Create a function to roll the dice
		 rollDice();
		 
		 setVisible(true);
	}
	//This class is to create die1
	private void buildDie1Panel() {
		die1Panel = new JPanel();
		die1Label = new JLabel();
		die1Panel.add(die1Label);
	}
	//This class will create die2
	private void buildDie2Panel() {
		die2Panel = new JPanel();
		die2Label = new JLabel();
		die2Panel.add(die2Label);
	}
		//This class is to create the button panel
		//Add in an eventlistener when clicked on
	   private void buildButtonPanel()
	   {
	      buttonPanel = new JPanel();
	      button = new JButton("Roll");
	      button.setMnemonic(KeyEvent.VK_R);
	      button.setToolTipText("Click here to roll the dice.");
	      button.addActionListener(new ButtonListener());
	      buttonPanel.add(button);
	   }
	   //This class is to add in the images of the dice which will be stored in an array
	   private void buildDieImageList()
	   {
	
	      dieImageList = new ArrayList<>();
	      dieImageList.add(new ImageIcon("Dice\\Die1.png"));
	      dieImageList.add(new ImageIcon("Dice\\Die2.png"));
	      dieImageList.add(new ImageIcon("Dice\\Die3.png"));
	      dieImageList.add(new ImageIcon("Dice\\Die4.png"));
	      dieImageList.add(new ImageIcon("Dice\\Die5.png"));
	      dieImageList.add(new ImageIcon("Dice\\Die6.png"));                                                    
	   }
	   //This class is to roll the dice
	   //Import a random function and use the array from the previous class to display the dice
	   private void rollDice()
	   {
	 
	      Random rand = new Random();      
	      int index1 = rand.nextInt(dieImageList.size());
	      int index2 = rand.nextInt(dieImageList.size());
	      die1Image = dieImageList.get(index1);
	      die2Image = dieImageList.get(index2);
	      die1Label.setIcon(die1Image); 
	      die2Label.setIcon(die2Image);                                                 
	   }  
	   //Create the event listener class to roll the dice
	   private class ButtonListener implements ActionListener
	   {
	      public void actionPerformed(ActionEvent e)
	      {
	         rollDice();
	      }
	   }
	   //Main class to create the dice simulator
	   public static void main(String[] args)
	   {
	      DiceSimulator ds = new DiceSimulator();
	   }

	
}
