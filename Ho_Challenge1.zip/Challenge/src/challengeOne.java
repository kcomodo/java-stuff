import java.awt.Graphics2D;
import java.awt.Point;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Dimension;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Graphics;
/*
 * Quang Ho
 * 2/14/2021
 * Connect 3 
 * Challenge One
 * CPT 262 Advanced Java Programming
 * Create a game called "Connect 3"
 * User will have a 4 x 4 grid
 * Allow user to place circles on grid
 * Circle will drop to the bottom of grid
 * 2 Players, Green and DarkGray
 * Notify the winner
 * Board should be light gray
 * 24 different winning combination
 */
public class challengeOne {
	//Frame of board is created
    private JFrame boardFrame;
    //Name of the board will be called "Connect 3"
    public challengeOne() {
        boardFrame = new JFrame("Connect 3");
        //Set the size of the board (made it small)
        boardFrame.setSize(350, 300);
        //Board will close on exit (clicked the exit button)
        boardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Set the size of the frame
        boardFrame.setPreferredSize(boardFrame.getSize());
        boardFrame.add(new MultiDraw(boardFrame.getSize()));
        //Make the board visible or else the user can't play
        boardFrame.setVisible(true);
    }
    //Call the main method so the application can run
    public static void main(String[] args) {
        new challengeOne();
    }
    //This class will set all the variables for the players and board
    public static class MultiDraw extends JPanel  implements MouseListener {
    	//Initialize a winner as false
    	boolean winner=false;
    	//Board will be 4 x 4, so create both row and columns 4 by 4
    	int boardRows = 4;
        int boardCols = 4;
        //cells is basically cellsize of the board, can be change to make it bigger
        int cells = 60;
        //playersTurn will have 2 player
        int playerTurns = 2;
        //Starting position for both X and Y will be 10
        int xPos = 10;
        int yPos = 10;
        //colorName will be a string to display the winner at the end 
        String colorName = "";
        //boardGrid is to initialize each columns and rows 
        //So that the user can click on it
        Color[][] boardGrid = new Color[boardRows][boardCols];
        //The dimension function prevents the value of the board to go negative, 
        //meaning the width and height will remain the same
        public MultiDraw(Dimension boardDimension) {
            setSize(boardDimension);
            setPreferredSize(boardDimension);
            //Initialize a mouse listener for the board
            addMouseListener(this);
            //For each rows and columns, it will be filled in with a white circle
            //This allow the user to know which piece has not been filled in
            int x = 0;
            for (int selectedRow = 0; selectedRow < boardGrid.length; selectedRow++) {
                for (int selectedCol = 0; selectedCol < boardGrid[0].length; selectedCol++) {
                    Color color;
                    if(x%2==0){
                        boardGrid[selectedRow][selectedCol] = Color.white; 
                    }else{
                        boardGrid[selectedRow][selectedCol] = Color.white;
                    }
                    x++;

                }

            }
        }
        //Graphics function will draw the board as well as the pieces
        @Override
        public void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D)g;
            Dimension d = getSize();
            g2.setColor(new Color(192, 192, 192));
            g2.fillRect(0,0,d.width,d.height);
            //Each row and column will be drawn as an oval, could draw it as a rectangle, 
            //but a connect 4 board has circle pieces
            xPos = 0;
            yPos = 0;
            for (int row = 0; row < boardGrid.length; row++) {
                for (int col = 0; col < boardGrid[0].length; col++) {

                    g2.setColor(boardGrid[row][col]);
                    g2.fillOval(xPos,yPos,cells,cells);
                    //Setting the color to black will fill the outside of the circle
                    g2.setColor(Color.black);
                    g2.drawOval(xPos,yPos,cells,cells);
                    xPos += cells;
                }
                yPos += cells;
                xPos = 0;
            }
            //This section decides which players turn it is
            //If the winner condition is still false, the game will continue until there's a winner
            g2.setColor(new Color(0, 0, 0));
            if(winner==false){
            	//A message will be displayed on the right side to determine who's turn it is 
            	//and who's the winner
                if(playerTurns%2==0)
                    g2.drawString("Green Turn",250,30);
                else
                    g2.drawString("Gray Turn",250,30);
            }else{
                g2.drawString("Winner: "+ colorName,250,30);
            }

        }
        //The mouse pressed function will get the position of the user when they click on the board.
        public void mousePressed(MouseEvent mouseClicked) {
        	//Initialize the Y and X coordinate of when the user clicks on the board
        	int clickedY = mouseClicked.getY();
            int clickedX = mouseClicked.getX();
            //When the pieces are clicked by the user, a circle will fill it's place
            if(winner==false){
                if(clickedX<(cells*boardGrid[0].length) && clickedY<(cells*boardGrid.length)){
                    int rowClicked = clickedY/cells;
                    int clickedCol = clickedX/cells;

                    rowClicked = dropDisk(clickedCol);
                    //Player 1 will get the green circle while player 2 will get the Gray circle
                    if(rowClicked!=-1){

                        if(playerTurns%2==0){
                            boardGrid[rowClicked][clickedCol]= Color.green;
                            colorName =  "Green";
                        } else{
                            boardGrid[rowClicked][clickedCol]= Color.gray;
                            colorName =  "Gray";
                        }
                        playerTurns++;
                        //If the condition is true, the winner boolean will be true
                        if(checkForWinner(clickedCol,rowClicked, boardGrid[rowClicked][clickedCol])){
                            winner=true;

                        }
                    }
                }
                repaint();
            }
        }
        //This section allows the disk to be dropped
     
        public int dropDisk(int columnsClicked){
        	  //Each time a user click on a row or column
        	  //The disk will drop all the way down
            int rowsClicked = boardGrid.length-1;
            //Other remaining disk that aren't filled will remain white
            while(rowsClicked>=0){ 
                if(boardGrid[rowsClicked][columnsClicked].equals(Color.white)){
                    return rowsClicked;
                }
                rowsClicked--;
            }

            return -1;

        }
        //Other mouse event functions will be left blank
        public void mouseReleased(MouseEvent e) {

        }

        public void mouseEntered(MouseEvent e) {

        }
        //When the user exit the game, the pieces will reset by calling a method
        public void mouseExited(MouseEvent e) {
            resetBoard();
        }

        public void mouseClicked(MouseEvent e) {

        }
        
    
        //This section will check for the winner
        public boolean  checkForWinner(int rowsClicked, int columnsClicked, Color color){
         //It will take the position of the rows and columns from the players color 
         //and determine if they won or not
            int xPos = columnsClicked;
            int c = 1;
            xPos--;
            /*
             * Down below I've created a loop that checks every corner and side of the board 
             * This will match each pieces with one another and decide if the color are align
             */
            //This loop will check left side of the board
            while(xPos>=0){
                if(boardGrid[columnsClicked][xPos].equals(color)){
                    c++;
                }else{
                    break;
                }
                if(c==4)
                    return true;

                xPos--;
            }
            xPos = columnsClicked;
            xPos++;
            //This loop will check the right side of the board
            while(xPos<boardGrid[0].length){
                if(boardGrid[rowsClicked][xPos].equals(color)){
                    c++;
                }else{
                    break;
                }
                if(c==4)
                    return true;

                xPos++;
            }
            c = 1;
            int yPos = rowsClicked;
            yPos--;
            //This loop will check the top of the board
            while(yPos>0){
                if(boardGrid[yPos][columnsClicked].equals(color)){
                    c++;
                }else{
                    break;
                }
                if(c==4)
                    return true;

                yPos--;
            }
            yPos = rowsClicked;
            yPos++;
            while(yPos<boardGrid.length){

                if(boardGrid[yPos][columnsClicked].equals(color)){
                    c++;
                }else{
                    break;
                }
                if(c==4)
                    return true;

                yPos++;
            }
            c = 1;
            yPos = rowsClicked;
            xPos = columnsClicked;
            xPos--;
            yPos--;
            //This will check the top left side of the board
            while(yPos>0 && xPos>0){
                if(boardGrid[yPos][xPos].equals(color)){
                    c++;
                }else{
                    break;
                }
                if(c==4)
                    return true;

                yPos--;
                xPos--;
            }
            yPos = rowsClicked;
            yPos++;
            xPos = columnsClicked;
            xPos++;
            //This will check the bottom right side of the board
            while(yPos<boardGrid.length && xPos<boardGrid.length){

                if(boardGrid[yPos][xPos].equals(color)){

                    c++;
                }else{
                    break;
                }
                if(c==4)
                    return true;

                yPos++;
                xPos++;
            }
            c = 1;
            yPos = rowsClicked;
            xPos = columnsClicked;
            xPos --;
            yPos++;
            //This will check the bottom left side of the board
            while(yPos<boardGrid.length && xPos>0){
                if(boardGrid[yPos][xPos].equals(color)){
                    c++;
                }else{
                    break;
                }
                if(c==4)
                    return true;
                yPos++;
                xPos--;
            }
            yPos = rowsClicked;
            yPos--;
            xPos = columnsClicked;
            xPos++;
            //This will check the top right of the board
            while(yPos>0 && xPos<boardGrid.length){
                if(boardGrid[yPos][xPos].equals(color)){
                    c++;
                }else{
                    break;
                }
                if(c==4)
                    return true;
                yPos--;
                xPos++;
            }
            return false;
        }
        //This method will reset the board when the user exits the application
        public void resetBoard(){
        	//Winner will be reset back to false
        	//Players will return to 2
        	//The pieces in the board will all turn back to white
            winner=false;
            playerTurns=2;
            for (int selectedRow = 0; selectedRow < boardGrid.length; selectedRow++) {
                for (int selectedCol = 0; selectedCol < boardGrid[0].length; selectedCol++) {
                    boardGrid[selectedRow][selectedCol] = Color.white; 

                }
            }
        }

    }
}