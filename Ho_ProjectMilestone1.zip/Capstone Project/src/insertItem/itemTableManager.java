package insertItem;

public class itemTableManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
