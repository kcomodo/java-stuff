package Challenge9;
import javax.swing.*;
import java.awt.*;



public class panelBuilder extends JPanel
{
   private JTextField nameTextField;      
   private JTextField phoneTextField;  

   
   public panelBuilder()
   {
      // Create labels and text fields
      // for the user data.
      
      JLabel namePrompt = new JLabel("Name");
      nameTextField = new JTextField(45);
      
      JLabel phonePrompt = new JLabel("Phone");
      phoneTextField = new JTextField(20);
 
      

      setLayout(new GridLayout(12, 1));   
      setBorder(BorderFactory.createTitledBorder("Enter User Information"));

      add(namePrompt);
      add(nameTextField);
      
      add(phonePrompt);
      add(phoneTextField);

   }
   
	public void setName(String name)
	{
		nameTextField.setText(name);
	}
	public void setPhone(String phone)
	{
		phoneTextField.setText(phone);
	}

   
   public String getName()
   {
      return nameTextField.getText();
   }

   
   public String getPhone()
   {
	     return phoneTextField.getText();
   }
   
  
   
   public void clear()
   {
      nameTextField.setText("");
      phoneTextField.setText("");
 
   }
}