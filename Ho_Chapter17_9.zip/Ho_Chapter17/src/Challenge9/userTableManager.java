package Challenge9;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class userTableManager
{
	//access database table
   public final String DB_URL = 
                "jdbc:ucanaccess://PhoneBook.accdb";


   private static Connection conn;

   /**
      Constructor
    */
   
   public userTableManager() throws SQLException
   {
     //connect to database
      conn = DriverManager.getConnection(DB_URL);
   }

   /*
    * Insert field, lets the user insert information
    */
   public void insert(String name, String phone) 
                      throws SQLException
   {
     //Will connect to the Entries table and insert name and number
	   String ourSQLInsert = "INSERT INTO Entries (personName, number)"
	   		+  "VALUES (?, ?)";  
	   PreparedStatement prepStmt = conn.prepareStatement(ourSQLInsert);

	   prepStmt.setString(1, name);
	   prepStmt.setString(2, phone);

	   prepStmt.executeUpdate();
	   prepStmt.close();
   }
   //A table that displays the information
   public static ResultSet selectUsers(String name, String phone) 
           throws SQLException
{
	   //Get name and number from entries table
	   String ourSQLSelect = "SELECT personName as Name, number as number from Entries where personName Like ? AND"
	   		+ " number Like ?";  
                
	          

	PreparedStatement prepStmt = conn.prepareStatement(ourSQLSelect);

	prepStmt.setString(1, "%" + name + "%");
	prepStmt.setString(2, "%" + phone + "%");

	ResultSet userResults = prepStmt.executeQuery();


		return userResults;
	}
   //Update field,  allows the user to choose a section and update the information
	public static ResultSet selectUpdate(String ID) 
	           throws SQLException
	{
				
		//Allow user to select a field and update the information
		String ourSQLSelect = "SELECT ID as ID, personName as Name, number as number,"
					+ " from Entries where ID = ?";  
		          
		
		PreparedStatement prepStmt = conn.prepareStatement(ourSQLSelect);
		
		
		prepStmt.setString(1, ID);
		
		
		ResultSet userResults = prepStmt.executeQuery();
		
		
		return userResults;
	}
	//Record will update and display the new information
	public void updateRecord (String name, String number
				) throws SQLException {
		
		String ourSQLUpdate = "update Entries set personName = ?, "
				+ "number =  ?,	WHERE ID = ?";
		
		
		PreparedStatement prepStmt = conn.prepareStatement(ourSQLUpdate);


	prepStmt.setString(1, name);
	prepStmt.setString(2, number);
	
	
	prepStmt.executeUpdate();
	prepStmt.close();
	}
}
