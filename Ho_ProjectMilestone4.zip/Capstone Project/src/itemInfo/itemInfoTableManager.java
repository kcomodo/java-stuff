package itemInfo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class itemInfoTableManager {

	 // Create a named constant for the URL.
	   // NOTE: This value is specific for Java DB
	   public final String DB_URL = 
	                "jdbc:ucanaccess://Capstone.accdb";

	   // Field for the database connection
	   private static Connection conn;

	   /**
	      Constructor
	    */
	   
	   public itemInfoTableManager() throws SQLException
	   {
	      // Create a connection to the database.
	      conn = DriverManager.getConnection(DB_URL);
	   }
	   public static ResultSet selectUsers(String itemName,  int itemPrice, int itemQuantity) 
               throws SQLException
	{
	
	String ourSQLSelect = "SELECT itemName as name, itemPrice as item, itemQuantity as quantity, "
					+ "from itemdetail where itemName Like ? AND"
					+ " itemPrice Like ? AND itemQuantity Like ?";  
	              
	// Create a Statement object.
	PreparedStatement prepStmt = conn.prepareStatement(ourSQLSelect);
	
	
	prepStmt.setString(1, "%" + itemName + "%");
	prepStmt.setString(2, "%" + itemPrice + "%");
	prepStmt.setString(3, "%" + itemQuantity + "%");
	
	//Executes the query, note that the command is slightly different than select, due to the fact that
	//no results are being returned
	ResultSet userResults = prepStmt.executeQuery();
	
	
	return userResults;
	}
	  
}
