package itemInfo;


import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class itemInfoPanelBuilder extends JPanel{
	  private JTextField itemnameTextField;      
	   private JTextField priceTextField;   
	   private JTextField quantityTextField;    
	
	   
	   public itemInfoPanelBuilder()
	   {
	      // Create labels and text fields
	      // for the user data.
	      
	      JLabel itemnamePrompt = new JLabel("Item Name");
	      itemnameTextField = new JTextField(45);
	      
	      JLabel pricePrompt = new JLabel("Price");
	      priceTextField = new JTextField(55);
	      
	      JLabel quantityPrompt = new JLabel("Quantity");
	      quantityTextField = new JTextField(45);
	      
	
	      
	      // Create a grid layout manager 
	      // with 12 rows and 1 column.
	      setLayout(new GridLayout(12, 1));   
	      setBorder(BorderFactory.createTitledBorder("Enter User Information"));
	      
	      // Add the labels and text fields
	      // to the panel.
	      
	      add(itemnamePrompt);
	      add(itemnameTextField);
	      
	      add(pricePrompt);
	      add(priceTextField);
	      
	      add(quantityPrompt);
	      add(quantityTextField);
	      
	    
	   }
	   
	      
	   /**
	      The getName method returns the 
	      name entered by the user.
	      @return The name
	    */
	   
	   public String getitemName()
	   {
	      return itemnameTextField.getText();
	   }
	   /**
	      The getAddress method returns the 
	      address entered by the user.
	      @return The address
	    */
	   
	   public int getPrice()
	   {
		   String getText = priceTextField.getText();
	       return Integer.parseInt(getText);	
	   }

	   /**
	      The getEmail method returns the 
	      email entered by the email.
	      @return The email
	    */
	   
	   public int getQuantity()
	   {
		   String getText = quantityTextField.getText();
	       return Integer.parseInt(getText);	   
	       }
	   

	
	            
	   /**
	      The clear method sets each of the 
	      text fields to an empty string.
	    */
	   
	   public void clear()
	   {
	      itemnameTextField.setText("");
	      priceTextField.setText("");
	      quantityTextField.setText("");
	  
	   }
}