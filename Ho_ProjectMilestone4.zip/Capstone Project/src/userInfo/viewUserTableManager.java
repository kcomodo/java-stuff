package userInfo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class viewUserTableManager {
	 // Create a named constant for the URL.
	   // NOTE: This value is specific for Java DB
	   public final String DB_URL = 
	                "jdbc:ucanaccess://Capstone.accdb";

	   // Field for the database connection
	   private static Connection conn;

	   /**
	      Constructor
	    */
	   
	   public viewUserTableManager() throws SQLException
	   {
	      // Create a connection to the database.
	      conn = DriverManager.getConnection(DB_URL);
	   }
	   public static ResultSet selectUsers(String userName,  String userPassword, String userPermission) 
               throws SQLException
	{
	
	String ourSQLSelect = "SELECT userName as name, userPassword as password, userPermission as permission"
					+ "from user where userName Like ? AND"
					+ " userPassword Like ? AND userPermission Like ?";  
	              
	// Create a Statement object.
	PreparedStatement prepStmt = conn.prepareStatement(ourSQLSelect);
	
	
	prepStmt.setString(1, "%" + userName + "%");
	prepStmt.setString(2, "%" + userPassword + "%");
	prepStmt.setString(3, "%" + userPermission + "%");


	
	//Executes the query, note that the command is slightly different than select, due to the fact that
	//no results are being returned
	ResultSet userResults = prepStmt.executeQuery();
	
	
	return userResults;
	}
	   

}
