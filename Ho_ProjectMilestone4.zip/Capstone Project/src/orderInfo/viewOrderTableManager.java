package orderInfo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class viewOrderTableManager {
	 // Create a named constant for the URL.
	   // NOTE: This value is specific for Java DB
	   public final String DB_URL = 
	                "jdbc:ucanaccess://Capstone.accdb";

	   // Field for the database connection
	   private static Connection conn;

	   /**
	      Constructor
	    */
	   
	   public viewOrderTableManager() throws SQLException
	   {
	      // Create a connection to the database.
	      conn = DriverManager.getConnection(DB_URL);
	   }
	   public static ResultSet selectUsers(String itemName,  String address, String city, String state, int zip) 
               throws SQLException
	{
	
	String ourSQLSelect = "SELECT itemName as name, orderAddress as address, orderCity as city, orderState as state, orderZip as zip"
					+ "from order where itemName Like ? AND"
					+ " orderAddress Like ? AND orderCity Like ? AND orderState Like ? AND orderZip Like ?";  
	              
	// Create a Statement object.
	PreparedStatement prepStmt = conn.prepareStatement(ourSQLSelect);
	
	
	prepStmt.setString(1, "%" + itemName + "%");
	prepStmt.setString(2, "%" + address + "%");
	prepStmt.setString(3, "%" + city + "%");
	prepStmt.setString(3, "%" + state + "%");
	prepStmt.setString(3, "%" + zip + "%");


	
	//Executes the query, note that the command is slightly different than select, due to the fact that
	//no results are being returned
	ResultSet userResults = prepStmt.executeQuery();
	
	
	return userResults;
	}
	   

}
