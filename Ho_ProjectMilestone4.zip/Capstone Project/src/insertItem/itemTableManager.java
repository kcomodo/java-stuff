package insertItem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class itemTableManager {

	 // Create a named constant for the URL.
	   // NOTE: This value is specific for Java DB
	   public final String DB_URL = 
	                "jdbc:ucanaccess://Capstone.accdb";

	   // Field for the database connection
	   private Connection conn;

	   /**
	      Constructor
	    */
	   
	   public itemTableManager() throws SQLException
	   {
	      // Create a connection to the database.
	      conn = DriverManager.getConnection(DB_URL);
	   }
	   
	   public void insert(String itemName, int itemPrice, int itemQuantity) 
	                      throws SQLException
	   {
	     
		   String ourSQLInsert = "INSERT INTO itemdetail (itemName, itemPrice, itemQuantity)"
		   		+  "VALUES (?, ?, ?)";  
	                     
		   // Create a Statement object.
		   PreparedStatement prepStmt = conn.prepareStatement(ourSQLInsert);

		   //Statement to insert our variables into the prepared sql placeholders.  Number is the position
		   //that the question mark is at above, starting at one.  Variable types matter
		   prepStmt.setString(1, itemName);
		   prepStmt.setInt(2, itemPrice);
		   prepStmt.setInt(3, itemQuantity);

		   

		   //Executes the query, note that the command is slightly different than select, due to the fact that
		   //no results are being returned
		   prepStmt.executeUpdate();
		   prepStmt.close();
	   }

}
