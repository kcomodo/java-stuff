package Ho_Chapter9_11;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;
/* 
 *  Quang Ho
 *  9/20/2020
 *  Chapter 9
 *  Challenge 11
 *  Sales Analysis
 *  Create a program that reads a text file
 *  The program will find out the total sales, average sales and total sales for all weeks
 *  Should also find average weekly sales as well as the highest and lowest amount of sales
 */
public class salesAnalysis {

	public static void main(String[] args) throws FileNotFoundException {
		// Import the "SalesData.txt" 
		 File file = new File("SalesData.txt");
		 Scanner inputFile = new Scanner(file);
		 //Variables for total, average, highest and lowest
		 int num=0;
		 int num1=0;
		 int numCount=0;
		 double totalSales=0;
		 double total=0;
		 double highestSales=0;
		 double lowestSales=Integer.MAX_VALUE;
		 //break string into token with ","
		while(inputFile.hasNext())
		{
		String s = inputFile.nextLine();
		StringTokenizer token = new StringTokenizer(s,",");
		numCount++;
		//Create loops and if statements to find total, lowest and highest
			while(token.hasMoreTokens())
			{
			total+=Double.parseDouble(token.nextToken());
			}

			if(total>highestSales)
			{
				highestSales=total;
				num=numCount;
			}

			if (total<lowestSales)
			{
			lowestSales=total;
			num1=numCount;
			}

			//Add the total of all weeks together
			totalSales+=total;
			//Print out the total and average sales for each weeks
		System.out.println("Week " + numCount + " Total sales: "+ total);
		System.out.println("Week " + numCount + " Average sales: "+ (total/7));
		total=0;
		}
		//print out the total sales from all weeks combined
		//Print out average as well as highest and lowest sales
		System.out.println("The total sales of all weeks: "+ totalSales);
		System.out.println("The average weekly sales: "+ (totalSales/numCount));
		System.out.println("Highest Week Sales: "  + highestSales + " for week " + num );
		System.out.println("Lowest Week Sales: "   + lowestSales + " for week " + num1 );
		
	}
}
