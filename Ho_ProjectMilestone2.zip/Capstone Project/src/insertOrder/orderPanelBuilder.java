package insertOrder;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class orderPanelBuilder extends JPanel{
	 private JTextField itemnameTextField;     
	   private JTextField addressTextField;   
	   private JTextField cityTextField;   
	   private JTextField stateTextField;  
	   private JTextField zipTextField;  
	
	   
	   public orderPanelBuilder()
	   {
	      // Create labels and text fields
	      // for the user data.
	      
	      JLabel itemnamePrompt = new JLabel("Item Name");
	      itemnameTextField = new JTextField(45);
	      
	      JLabel addressPrompt = new JLabel("Address");
	      addressTextField = new JTextField(55);
	      
	      JLabel cityPrompt = new JLabel("City");
	      cityTextField = new JTextField(45);
	      
	      JLabel statePrompt = new JLabel("State");
	      stateTextField = new JTextField(45);
	      
	      JLabel zipPrompt = new JLabel("Zip");
	      zipTextField = new JTextField(5);
	      
	
	      
	      // Create a grid layout manager 
	      // with 12 rows and 1 column.
	      setLayout(new GridLayout(12, 1));   
	      setBorder(BorderFactory.createTitledBorder("Enter User Information"));
	      
	      // Add the labels and text fields
	      // to the panel.
	      
	      add(itemnamePrompt);
	      add(itemnameTextField);
	      
	      add(addressPrompt);
	      add(addressTextField);
	      
	      add(cityPrompt);
	      add(cityTextField);
	      
	      add(statePrompt);
	      add(stateTextField);
	      
	      add(zipPrompt);
	      add(zipTextField);
	      
	    
	   }
	   
	      
	   /**
	      The getName method returns the 
	      name entered by the user.
	      @return The name
	    */
	   
	   public String getitemName()
	   {
	      return itemnameTextField.getText();
	   }
	   /**
	      The getAddress method returns the 
	      address entered by the user.
	      @return The address
	    */
	   
	   public String getAddress()
	   {
		   return addressTextField.getText();
	   
	   }

	   public String getCity()
	   {
		   return cityTextField.getText();
	   
	   }
	   public String getState()
	   {
		   return stateTextField.getText();
	   
	   }

	   
	   public int getZip()
	   {
		   String getText = zipTextField.getText();
	       return Integer.parseInt(getText);	   
	       }
	   

	
	            

	   
	   public void clear()
	   {
	      itemnameTextField.setText("");
	      addressTextField.setText("");
	      cityTextField.setText("");
	      stateTextField.setText("");
	      zipTextField.setText("");
	  
	   }

}
