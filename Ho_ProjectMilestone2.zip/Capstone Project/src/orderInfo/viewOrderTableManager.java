package orderInfo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class viewOrderTableManager {
	 // Create a named constant for the URL.
	   // NOTE: This value is specific for Java DB
	   public final String DB_URL = 
	                "jdbc:ucanaccess://Capstone.accdb";

	   // Field for the database connection
	   private Connection conn;

	   /**
	      Constructor
	    */
	   
	   public viewOrderTableManager() throws SQLException
	   {
	      // Create a connection to the database.
	      conn = DriverManager.getConnection(DB_URL);
	   }
	   

}
