package userInfo;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class viewUserPanelBuilder extends JPanel{
	 private JTextField usernameTextField;     
	   private JTextField passwordTextField;   
	   private JTextField permissionTextField;   

	
	   
	   public viewUserPanelBuilder()
	   {
	      // Create labels and text fields
	      // for the user data.
	      
	      JLabel usernamePrompt = new JLabel("User Name");
	      usernameTextField = new JTextField(45);
	      
	      JLabel passwordPrompt = new JLabel("Password");
	      passwordTextField = new JTextField(55);
	      
	      JLabel permissionPrompt = new JLabel("Permission");
	      permissionTextField = new JTextField(45);

	      
	
	      
	      // Create a grid layout manager 
	      // with 12 rows and 1 column.
	      setLayout(new GridLayout(12, 1));   
	      setBorder(BorderFactory.createTitledBorder("Enter User Information"));
	      
	      // Add the labels and text fields
	      // to the panel.
	      
	      add(usernamePrompt);
	      add(usernameTextField);
	      
	      add(passwordPrompt);
	      add(passwordTextField);
	      
	      add(permissionPrompt);
	      add(permissionTextField);
	      
	
	      
	    
	   }
	   
	      

	   
	   public String getUserName()
	   {
	      return usernameTextField.getText();
	   }

	   public String getPassword()
	   {
		   return passwordTextField.getText();
	   
	   }

	   public String getPermission()
	   {
		   return permissionTextField.getText();
	   
	   }

	   

	
	            

	   
	   public void clear()
	   {
	      usernameTextField.setText("");
	      passwordTextField.setText("");
	      permissionTextField.setText("");

	  
	   }
}
