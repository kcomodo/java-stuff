package Ho_Chapter_11_7;

import java.io.*;

public class Crypto {
	public static void encryptFile(String existing, String encrypted) throws IOException {
		/*
		 * Open the first file
		 * Read the file
		 * Create a second file
		 * Encrypt the first file
		 * Transfer the encrypted code to the second file
		 */
		boolean eof = false;
		
		FileInputStream inStream = new FileInputStream(existing);
		DataInputStream inFile = new DataInputStream(inStream);
		FileOutputStream outStream = new FileOutputStream(encrypted);
		DataOutputStream outFile = new DataOutputStream(outStream);
		/*
		 * Read the first file one character at a time
		 * Encrypt it by adding 10 to each characters
		 * Output it to the second file
		 */
		while(!eof) {
			try {
				byte input = inFile.readByte();
				input+=10;
				outFile.writeByte(input);
			}
			catch(EOFException e) {
				eof = true;
			}
		}
		inFile.close();
		outFile.close();
	}
}
