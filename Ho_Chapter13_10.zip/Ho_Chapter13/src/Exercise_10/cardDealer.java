package Exercise_10;
import java.util.ArrayList;
import java.util.Random;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class cardDealer extends JFrame
{
	//set height for window 
	//set width for window
	private final int WINDOW_HEIGHT = 320; 
   private final int WINDOW_WIDTH = 380;  
   /*
    * Insert panel for deck and card as well as button
    * Insert labels for deck and card
    * Insert image icons for card and deck
    * Insert a container
    * Insert array list for image to hold
    */
   private JPanel buttonPanel;  
   private JPanel deckPanel;        
   private JPanel cardPanel;            
   private JLabel cardLabel;
   private JLabel deckLabel;  
   private ImageIcon cardImage;    
   private ImageIcon deckImage;    
   private JButton button;         
   private Container contentPane;  
   
   private ArrayList<ImageIcon> cardImageList; 

   
   public cardDealer()
   {
      // Title: Card Dealer
      setTitle("Card Dealer");
   
      // Set size of window width and height
      setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

      // Specify what happens when the close button is clicked
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      // Create a border for the content pane.
      setLayout(new BorderLayout());
       
      // Build the cardImageList
      buildCardImageList();

      // Build the panels
      buildDeckPanel();
      buildButtonPanel();
      buildCardPanel();

      // Add the panels to the content pane
      add(deckPanel, BorderLayout.WEST);
      add(cardPanel, BorderLayout.EAST);
      add(buttonPanel, BorderLayout.SOUTH);

      // Display window
      setVisible(true);
   }



   private void buildDeckPanel()
   {
      // Create a panel
      deckPanel = new JPanel();

      // Create an image icon
      deckImage = new ImageIcon("Cards\\Backface_Blue.jpg");

      // Create a label for deck of cards
      deckLabel = new JLabel(deckImage);

      // Add the label to the panel.
      deckPanel.add(deckLabel);
   }


   private void buildCardPanel()
   {
      // Create a panel.
      cardPanel = new JPanel();

      // Create a label.
      cardLabel = new JLabel();

      // Add the label to the panel.
      cardPanel.add(cardLabel);
   }
  

   private void buildButtonPanel()
   {
      // Create a panel.
      buttonPanel = new JPanel();
   
      // Create a button.
      button = new JButton("Deal a Card");
      button.setMnemonic(KeyEvent.VK_D);
      button.setToolTipText("Click here to deal a card.");
      
      // Register an action listener with the button.
      button.addActionListener(new ButtonListener());
      
      // Add the button to the panel.
      buttonPanel.add(button);
   }


   private void buildCardImageList()
   {
      // Create the cardImageList ArrayList to hold images
      cardImageList = new ArrayList<>();
      
      // Add the ImageIcon to the cardImageList list
      cardImageList.add(new ImageIcon("Cards\\2_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\2_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\2_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\2_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\3_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\3_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\3_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\3_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\4_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\4_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\4_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\4_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\5_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\5_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\5_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\5_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\6_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\6_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\6_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\6_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\7_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\7_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\7_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\7_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\8_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\8_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\8_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\8_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\9_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\9_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\9_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\9_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\10_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\10_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\10_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\10_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\Jack_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Jack_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Jack_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Jack_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\Queen_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Queen_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Queen_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Queen_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\King_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\King_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\King_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\King_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\Ace_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Ace_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Ace_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Ace_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\Joker_Black.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Joker_Red.jpg"));                                                      
   }
  

   
   private class ButtonListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         // Determine if there are still cards left in the list
         if(cardImageList.size() != 0)
         {  
            // create random object for card
            Random rand = new Random();
   
            // Generate a random number between 0 and the number of card images left in the list and then store it
  
            int index = rand.nextInt(cardImageList.size());
   
            // Get a card image from the array list
            cardImage = cardImageList.get(index);
            
            // Display the card image
            cardLabel.setIcon(cardImage);
   
            // Remove the card image from the list
            cardImageList.remove(index);
         }
         else
         {
            // Remove card image from deck
            deckLabel.setIcon(null);
            
            // Display a message when there are no more cards
            JOptionPane.showMessageDialog(null, "There are no more cards left in the deck");
         }
      }
   }

   //Main class will cause window to display when ran
   public static void main(String[] args)
   {
      cardDealer cardDeal = new cardDealer();
   }
}
