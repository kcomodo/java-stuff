package Ho_16_8;

public class sumOfNumber {	
	//Call for the user input
	public static int sum(int num) {
		//If the number is not 0, the number will add onto itself
		  if (num != 0)
	            return num + sum(num - 1);
	        else
	            return num;
		
	}
}

