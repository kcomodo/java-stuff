package databaseGUIInsert;

import javax.swing.*;
import java.awt.*;

/**
   The panelBuilder class builds a panel containing the 
   labels and text fields for inserting data into the user
   table of the testdbgui database.
*/

public class panelBuilder extends JPanel
{
   private JTextField nameTextField;      // name
   private JTextField positionTextField;     // email
   private JTextField hrTextField;       // hourly rate 
   
   public panelBuilder()
   {
      // Create labels and text fields
      // for the user data.
      
      JLabel namePrompt = new JLabel("Employee Name");
      nameTextField = new JTextField(45);
      
      JLabel positionPrompt = new JLabel("Employee Position");
      positionTextField = new JTextField(45);
      
      JLabel hrPrompt = new JLabel("Hourly Pay Rate");
      hrTextField = new JTextField(10);
      
      // Create a grid layout manager 
      // with 12 rows and 1 column.
      setLayout(new GridLayout(12, 1));   
      setBorder(BorderFactory.createTitledBorder("Enter User Information"));
      
      // Add the labels and text fields
      // to the panel.
      
      add(namePrompt);
      add(nameTextField);
      
      add(positionPrompt);
      add(positionTextField);
      
      
      add(hrPrompt);
      add(hrTextField);
   }
   
      
   /**
      The getName method returns the 
      name entered by the user.
      @return The name
    */
   
   public String getName()
   {
      return nameTextField.getText();
   }
   /**
      The getAddress method returns the 
      address entered by the user.
      @return The address
    */
   


   /**
      The getEmail method returns the 
      email entered by the email.
      @return The email
    */
   
   public String getPosition()
   {
      return positionTextField.getText();
   }
   
   /**
      The getHR method returns the 
      hourly rate entered by the user.
      @return the hourly rate
    */
   
   public Double getHR()
   {
       String getText = hrTextField.getText();
       return Double.parseDouble(getText);
   }
   
            
   /**
      The clear method sets each of the 
      text fields to an empty string.
    */
   
   public void clear()
   {
      nameTextField.setText("");
      positionTextField.setText("");
      hrTextField.setText("");
   }
}
