import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;


public class rollDice extends JFrame{
	private final int WINDOW_WIDTH = 1000;
	private final int WINDOW_HEIGHT =350;
	private JPanel mainDicePanel;
	private JPanel dicePanel;
	private JPanel die1Panel;
	private JPanel die2Panel;
	private JPanel die3Panel;
	private JPanel die4Panel;

	private JPanel secondaryDicePanel;
	private JPanel seconddicePanel;
	private JPanel die5Panel;
	private JPanel die6Panel;
	private JPanel die7Panel;
	private JPanel die8Panel;

	private JPanel buttonPanel;
	private JLabel diceLabel;
	private JLabel die1Label;
	private JLabel die2Label;
	private JLabel die3Label;
	private JLabel die4Label;
	
	private JLabel die5Label;
	private JLabel die6Label;
	private JLabel die7Label;
	private JLabel die8Label;
	
	private ImageIcon diceImages;
	private ImageIcon die1Image;
	private ImageIcon die2Image;
	private ImageIcon die3Image;
	private ImageIcon die4Image;
	
	private ImageIcon die5Image;
	private ImageIcon die6Image;
	private ImageIcon die7Image;
	private ImageIcon die8Image;

	private JButton button;
	private Container contentPane;
	private ArrayList<ImageIcon> dieImageList;
	
	public rollDice() {

		setTitle("rollDice");

		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
	
		 buildDieImageList();
		
		 buildDie1Panel();
		 buildDie2Panel();
		 buildDie3Panel();
		 buildDie4Panel();
		 buildDie5Panel();
		 buildDie6Panel();
		 buildDie7Panel();
		 buildDie8Panel();
		 
		 builddicePanel();
		 buildButtonPanel();
		 
		 mainDicePanel = new JPanel();
	      mainDicePanel.setLayout(new FlowLayout(FlowLayout.CENTER));
	      add(dicePanel, BorderLayout.EAST);
	      mainDicePanel.add(die1Panel);
	      mainDicePanel.add(die2Panel);
	      mainDicePanel.add(die3Panel);
	      mainDicePanel.add(die4Panel);
	      add(mainDicePanel, BorderLayout.CENTER);
	      secondaryDicePanel= new JPanel();
	      secondaryDicePanel.setLayout(new FlowLayout(FlowLayout.CENTER));
	      add(dicePanel, BorderLayout.EAST);
	      secondaryDicePanel.add(die5Panel);
	      secondaryDicePanel.add(die6Panel);
	      secondaryDicePanel.add(die7Panel);
	      secondaryDicePanel.add(die8Panel);
	      add(secondaryDicePanel, BorderLayout.SOUTH);
		 add(buttonPanel, BorderLayout.NORTH);
		 diceRoll();
		 
		 setVisible(true);
	}
	   private void builddicePanel()
	   {
	 
	      dicePanel = new JPanel();

	      diceLabel = new JLabel(diceImages);

	      dicePanel.add(diceLabel);
	      
	      
	   }
	private void buildDie1Panel() {
		die1Panel = new JPanel();
		die1Label = new JLabel();
		die1Panel.add(die1Label);
	}
	private void buildDie2Panel() {
		die2Panel = new JPanel();
		die2Label = new JLabel();
		die2Panel.add(die2Label);
	}
	private void buildDie3Panel() {
		die3Panel = new JPanel();
		die3Label = new JLabel();
		die3Panel.add(die3Label);
	}
	private void buildDie4Panel() {
		die4Panel = new JPanel();
		die4Label = new JLabel();
		die4Panel.add(die4Label);
	}

	private void buildDie5Panel() {
		die5Panel = new JPanel();
		die5Label = new JLabel();
		die5Panel.add(die5Label);
	}
	private void buildDie6Panel() {
		die6Panel = new JPanel();
		die6Label = new JLabel();
		die6Panel.add(die6Label);
	}
	private void buildDie7Panel() {
		die7Panel = new JPanel();
		die7Label = new JLabel();
		die7Panel.add(die7Label);
	}
	private void buildDie8Panel() {
		die8Panel = new JPanel();
		die8Label = new JLabel();
		die8Panel.add(die8Label);
	}


	   private void buildButtonPanel()
	   {
	      buttonPanel = new JPanel();
	      button = new JButton("Roll");
	      button.setMnemonic(KeyEvent.VK_R);
	      button.setToolTipText("Click here to roll the dice.");
	      button.addActionListener(new ButtonListener());
	      buttonPanel.add(button);
	   }
	   private void buildDieImageList()
	   {
	
	      dieImageList = new ArrayList<>();
	      dieImageList.add(new ImageIcon("Dice\\d12_1.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_10.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_11.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_12.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_2.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_3.jpg")); 
	      dieImageList.add(new ImageIcon("Dice\\d12_4.jpg")); 
	      dieImageList.add(new ImageIcon("Dice\\d12_5.jpg")); 
	      dieImageList.add(new ImageIcon("Dice\\d12_6.jpg")); 
	      dieImageList.add(new ImageIcon("Dice\\d12_7.jpg")); 
	      dieImageList.add(new ImageIcon("Dice\\d12_8.jpg")); 
	      dieImageList.add(new ImageIcon("Dice\\d12_9.jpg")); 
	      
	   }
	   private void diceRoll()
	   {
	 
	      Random rand = new Random();      
	      int index1 = rand.nextInt(dieImageList.size());
	      int index2 = rand.nextInt(dieImageList.size());
	      int index3 = rand.nextInt(dieImageList.size());
	      int index4 = rand.nextInt(dieImageList.size());

	      int index5 = rand.nextInt(dieImageList.size());
	      int index6 = rand.nextInt(dieImageList.size());
	      int index7 = rand.nextInt(dieImageList.size());
	      int index8 = rand.nextInt(dieImageList.size());
	      
	      die1Image = dieImageList.get(index1);
	      die2Image = dieImageList.get(index2);
	      die3Image = dieImageList.get(index3);
	      die4Image = dieImageList.get(index4);

	      die5Image = dieImageList.get(index5);
	      die6Image = dieImageList.get(index6);
	      die7Image = dieImageList.get(index7);
	      die8Image = dieImageList.get(index8);

	      die1Label.setIcon(die1Image); 
	      die2Label.setIcon(die2Image); 
	      die3Label.setIcon(die3Image); 
	      die4Label.setIcon(die4Image); 

	      die5Label.setIcon(die5Image); 
	      die6Label.setIcon(die6Image); 
	      die7Label.setIcon(die7Image); 
	      die8Label.setIcon(die8Image);   

	   }  
	
	   private class ButtonListener implements ActionListener
	   {
	      public void actionPerformed(ActionEvent e)
	      {
	         diceRoll();
	      }
	   }
	
	
	
	
	public static void main(String[] args) {
		 rollDice rd = new rollDice();
	}

}
