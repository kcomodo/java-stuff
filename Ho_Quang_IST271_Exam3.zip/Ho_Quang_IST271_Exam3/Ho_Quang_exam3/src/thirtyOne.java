import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import java.util.ArrayList;
import java.util.Random;

/**
   This program demonstrates a solution to the
   Card Dealer programming challenge.
*/

public class thirtyOne extends JFrame
{
   private final int WINDOW_WIDTH = 900;  // Window width
   private final int WINDOW_HEIGHT = 320; // Window height
   
   private JPanel deckPanel;		// A panel to hold a label
   private JPanel mainCardPanel;        // A panel to hold a label
   private JPanel cardPanel;        // A panel to hold a label
   private JPanel cardPanel2;        // A panel to hold a label
   private JPanel cardPanel3;        // A panel to hold a label

   private JPanel buttonPanel;      // A panel to hold a button
   private JLabel deckLabel;        // A label to hold an image
   private JLabel cardLabel;        // A label to hold an image
   private JLabel cardLabel2;        // A label to hold an image
   private JLabel cardLabel3;        // A label to hold an image

   private ImageIcon deckImage;     // To hold a deck image
   private ImageIcon cardImage;     // To hold a card image
   private ImageIcon cardImage2;     // To hold a card image
   private ImageIcon cardImage3;     // To hold a card image

   private JButton button;          // A button to get a card from the deck
   private JButton button2;          // A button to get a card from the deck
   private JButton button3;          // A button to get a card from the deck
   private Container contentPane;   // To reference the content pane
   private ArrayList<ImageIcon> cardImageList;  // To hold the card images.
   int checker = 1;
   /**
      Constructor
   */
   
   public thirtyOne()
   {
      // Set the title.
      setTitle("thirtyOne");
   
      // Set the size of the window.
      setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

      // Specify what happens when the close button is clicked.
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
      
      // Create a BorderLayout manager for the content pane.
      setLayout(new BorderLayout());
       
      // Build the cardImageList
      buildCardImageList();

      // Build the panels.
      buildDeckPanel();
      buildButtonPanel();
      buildCardPanel();
      buildCardPanel2();
      buildCardPanel3();
   

      mainCardPanel = new JPanel();
      mainCardPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
      // Add the panels to the content pane.
      add(deckPanel, BorderLayout.WEST);
      mainCardPanel.add(cardPanel);
      mainCardPanel.add(cardPanel2);
      mainCardPanel.add(cardPanel3);
      add(mainCardPanel, BorderLayout.EAST);
      add(buttonPanel, BorderLayout.SOUTH);

      // Display the window.
      setVisible(true);
   }

   /**
      The buildDeckPanel method adds a label
      to a panel that displays an image of 
      a deck of cards.
   */

   private void buildDeckPanel()
   {
      // Create a panel.
      deckPanel = new JPanel();

      // Create an image icon to represent the deck of cards.
      deckImage = new ImageIcon("Cards\\Backface_Blue.jpg");

      // Create a label using the image for the deck of cards.
      deckLabel = new JLabel(deckImage);

      // Add the label to the panel.
      deckPanel.add(deckLabel);
   }

   /**
      The buildCardPanel method adds an empty label
      to a panel initially, but this label will be
      used to display a card from the deck once the
      user clicks the button.
   */

   private void buildCardPanel()
   {
      // Create a panel.
      cardPanel = new JPanel();

      // Create a label.
      cardLabel = new JLabel();

      // Add the label to the panel.
      cardPanel.add(cardLabel);
   }
  
   private void buildCardPanel2()
   {
      // Create a panel.
      cardPanel2 = new JPanel();

      // Create a label.
      cardLabel2 = new JLabel();

      // Add the label to the panel.
      cardPanel2.add(cardLabel2);
   }
   
   private void buildCardPanel3()
   {
      // Create a panel.
      cardPanel3 = new JPanel();

      // Create a label.
      cardLabel3 = new JLabel();

      // Add the label to the panel.
      cardPanel3.add(cardLabel3);
   }
   

   /**
      The buildButtonPanel method adds a button
      to a panel.
   */

   private void buildButtonPanel()
   {
      // Create a panel.
      buttonPanel = new JPanel();
   
      // Create a button.
      button = new JButton("Deal 3 Cards");
      button.setMnemonic(KeyEvent.VK_D);
      button.setToolTipText("Click here to deal a card.");
      
      button2 = new JButton("Hit");
      button2.setMnemonic(KeyEvent.VK_R);
      button2.setToolTipText("Click here to reveal a card.");
      
      button3 = new JButton("Stand");
      button3.setMnemonic(KeyEvent.VK_S);
      button3.setToolTipText("Click here to shuffle.");
      
      // Register an action listener with the button.
      button.addActionListener(new ButtonListener());
      button2.addActionListener(new ButtonListener2());
      button3.addActionListener(new ButtonListener3());
      
      // Add the button to the panel.
      buttonPanel.add(button);
      buttonPanel.add(button2);
      buttonPanel.add(button3);
      
      button3.setEnabled(false);
      button2.setEnabled(false);
   }


   /**
      The buildCardImageList method fills the 
      ArrayList with images of a deck of 
      poker cards.
   */

   private void buildCardImageList()
   {
      // Create the cardImageList ArrayList 
      // to hold the ImageIcon objects.
      cardImageList = new ArrayList<>();
      
      // Add the ImageIcon objects to the cardImageList ArrayList
      cardImageList.add(new ImageIcon("Cards\\2_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\2_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\2_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\2_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\3_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\3_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\3_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\3_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\4_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\4_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\4_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\4_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\5_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\5_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\5_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\5_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\6_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\6_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\6_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\6_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\7_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\7_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\7_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\7_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\8_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\8_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\8_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\8_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\9_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\9_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\9_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\9_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\10_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\10_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\10_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\10_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\Jack_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Jack_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Jack_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Jack_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\Queen_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Queen_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Queen_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Queen_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\King_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\King_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\King_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\King_Spades.jpg"));
      
      cardImageList.add(new ImageIcon("Cards\\Ace_Clubs.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Ace_Diamonds.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Ace_Hearts.jpg"));
      cardImageList.add(new ImageIcon("Cards\\Ace_Spades.jpg"));
                                                  
   }
  
   /**
      Private inner class that handles the event when
      the user clicks the button.
   */
   
   private class ButtonListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         // Determine if there are still card 
         // images left in the array list.
    	 button.setEnabled(false);
    	 button2.setEnabled(true);
         if(cardImageList.size() > 4)
         {  
            // Create a reference to a Random object.
            Random rand = new Random();
   
            // Generate a random number between 0 and the 
            // number of card images left in the array list,
            // and store the value in the index variable.
            int index = rand.nextInt(cardImageList.size());
   
            // Get a card image from the array list using
            // the index value that was generated randomly.
            cardImage = cardImageList.get(index);
            
            // Display the card image.
            cardLabel.setIcon(deckImage);
   
            // Remove the card image from the array list.
            cardImageList.remove(index);
            
            int index2 = rand.nextInt(cardImageList.size());
            
            // Get a card image from the array list using
            // the index value that was generated randomly.
            cardImage2 = cardImageList.get(index2);
            
            // Display the card image.
            cardLabel2.setIcon(deckImage);
   
            // Remove the card image from the array list.
            cardImageList.remove(index2);
            
            
            int index3 = rand.nextInt(cardImageList.size());
            
            // Get a card image from the array list using
            // the index value that was generated randomly.
            cardImage3 = cardImageList.get(index3);
            
            // Display the card image.
            cardLabel3.setIcon(deckImage);
   
            // Remove the card image from the array list.
            cardImageList.remove(index3);
            
            
         }
         else
         {
            // Remove the card image representing the deck of cards.
            deckLabel.setIcon(null);
            button3.setEnabled(true);
            button2.setEnabled(false);
            // Display a message indicating that there are no more 
            // cards left in the deck.
            JOptionPane.showMessageDialog(null, "There are " + 
                        "no more cards are left in the deck.");
         }
      }
   }

   private class ButtonListener2 implements ActionListener
   {

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if (checker == 1) {
			checker += 1;
			cardLabel.setIcon(cardImage);
			button.setEnabled(false);
		} else if (checker == 2) {
			checker += 1;
			cardLabel2.setIcon(cardImage2);
			button.setEnabled(false);
		} else if (checker == 3) {
			checker += 1;
			cardLabel3.setIcon(cardImage3);
			button.setEnabled(false);
		} 
	}
	   
   }
   
   private class ButtonListener3 implements ActionListener
   {

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int checker = 1;
		buildCardImageList();
		deckLabel.setIcon(deckImage);
		cardLabel.setIcon(null);
		cardLabel2.setIcon(null);
		cardLabel3.setIcon(null);

		button.setEnabled(true);
		button2.setEnabled(false);
		button3.setEnabled(false);
	}
	   
   }
   /**
      The main method creates an instance of the CardDealer
      class, causing it to display its window.
   */
   public static void main(String[] args)
   {
     thirtyOne to = new thirtyOne();
      
      to.setVisible(true);
   }

     

}