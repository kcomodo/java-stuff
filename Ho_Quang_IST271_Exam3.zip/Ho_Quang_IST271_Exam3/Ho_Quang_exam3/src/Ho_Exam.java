import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class Ho_Exam extends JFrame{
	public static final int WIDTH = 600;
	public static final int HEIGHT = 300;
	private JMenuBar mBar;
	private JPanel textPanel;
	private JMenu viewMenu;
	public Ho_Exam()
	{
		setTitle("Ho Exam");
		setSize(WIDTH, HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		createMenu();
		
		mBar = new JMenuBar();
		mBar.add(viewMenu);
		setJMenuBar(mBar);
	}
	public void createMenu() {
		viewMenu = new JMenu("Games");
		JMenuItem item;
		item = new JMenuItem("rollDice");
		item.addActionListener(new MenuListener());
		viewMenu.add(item);
		
		item = new JMenuItem("thirtyOne");
		item.addActionListener(new MenuListener());
		viewMenu.add(item);
	}
	private class MenuListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) {
			String actionCommand = e.getActionCommand();
			if(actionCommand.equals("rollDice"))
			{
				rollDice rd = new rollDice();
				rd.setVisible(true);
			}else if (actionCommand.equals("thirtyOne"))
			{
				thirtyOne to = new thirtyOne();
				to.setVisible(true);
			}else {
				System.out.print("How did you do this");
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ho_Exam ho = new Ho_Exam();
		ho.setVisible(true);
	}

}