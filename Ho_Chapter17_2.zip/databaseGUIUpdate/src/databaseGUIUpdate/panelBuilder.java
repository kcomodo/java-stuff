package databaseGUIUpdate;

import javax.swing.*;
import java.awt.*;

/**
   The panelBuilder class builds a panel containing the 
   labels and text fields for inserting data into the user
   table of the testdbgui database.
*/

public class panelBuilder extends JPanel
{
	
   private JTextField nameTextField;      // name
   private JTextField addressTextField;   // address
   private JTextField emailTextField;     // email
   private JTextField hrTextField;       // hourly rate 
   private JTextField cityTextField;
   private JTextField stateTextField;
   private JTextField zipTextField;

   
   public panelBuilder()
   {
      // Create labels and text fields
      // for the user data.
      
      JLabel namePrompt = new JLabel("Name");
      nameTextField = new JTextField(45);
      
      JLabel addressPrompt = new JLabel("Address");
      addressTextField = new JTextField(55);
      
      JLabel emailPrompt = new JLabel("Email");
      emailTextField = new JTextField(45);
      
      JLabel hrPrompt = new JLabel("Hourly Rate");
      hrTextField = new JTextField(10);
      
      JLabel statePrompt = new JLabel("State");
      stateTextField = new JTextField(45);
      
      JLabel cityPrompt = new JLabel("City");
      cityTextField = new JTextField(45);
      
      JLabel zipPrompt = new JLabel("Zip");
      zipTextField = new JTextField(45);
      
      // Create a grid layout manager 
      // with 12 rows and 1 column.
      setLayout(new GridLayout(12, 1));   
      setBorder(BorderFactory.createTitledBorder("Enter User Information"));
      
      // Add the labels and text fields
      // to the panel.
      
      add(namePrompt);
      add(nameTextField);
      
      add(addressPrompt);
      add(addressTextField);
      
      add(emailPrompt);
      add(emailTextField);
      
      add(hrPrompt);
      add(hrTextField);
      
      add(cityPrompt);
      add(cityTextField);
      
      add(statePrompt);
      add(stateTextField);
      
      add(zipPrompt);
      add(zipTextField);
   }
   
	   /**
	   The setName method sets the 
	   name entered by the user.
	 */
   
	
	public void setName(String name)
	{
		nameTextField.setText(name);
	}

	   /**
	   The setAddress method sets the 
	   address entered by the user.
	 */
	
	public void setAddress(String address)
	{
		addressTextField.setText(address);
	}     
	
	   /**
	   The setEmail method sets the 
	   email entered by the user.
	 */
	
	public void setEmail(String email)
	{
		emailTextField.setText(email);
	} 
	
	   /**
	   The setHourlyRate method sets the 
	   rate entered by the user.
	 */
	
	public void setHR(Double hr)
	{
		hrTextField.setText(hr.toString());
	} 
	public void setCity(String city)
	{
		nameTextField.setText(city);
	}
	public void setState(String state)
	{
		nameTextField.setText(state);
	}
	public void setZip(String Zip)
	{
		nameTextField.setText(Zip);
	}
	
	
   /**
      The getName method returns the 
      name entered by the user.
      @return The name
    */
   
   public String getName()
   {
      return nameTextField.getText();
   }
   /**
      The getAddress method returns the 
      address entered by the user.
      @return The address
    */
   
   public String getAddress()
   {
      return addressTextField.getText();
   }

   /**
      The getEmail method returns the 
      email entered by the email.
      @return The email
    */
   
   public String getEmail()
   {
      return emailTextField.getText();
   }
   
   /**
      The getHR method returns the 
      hourly rate entered by the user.
      @return the hourly rate
    */
   
   public Double getHR()
   {
	   //Since hourly rate is a number field, we have to check to see if something is in the text field
	   //before we parse the value as a double.  If nothing is in the field we return a null so we can use
	   //that null value during the sql query to determine if we need to search for the hourly rate
       if (hrTextField.getText().equals("")) {
    	   return null;
       } else {
    	    String getText = hrTextField.getText();
       		return Double.parseDouble(getText);
       }
   }
   
            
   /**
      The clear method sets each of the 
      text fields to an empty string.
    */
   public String getCity()
   {
      return cityTextField.getText();
   }
   public String getState()
   {
      return stateTextField.getText();
   }
   public String getZip()
   {
      return zipTextField.getText();
   }
   
   public void clear()
   {
      nameTextField.setText("");
      addressTextField.setText("");
      emailTextField.setText("");
      hrTextField.setText("");
      stateTextField.setText("");
      cityTextField.setText("");
      zipTextField.setText("");
   }
}

