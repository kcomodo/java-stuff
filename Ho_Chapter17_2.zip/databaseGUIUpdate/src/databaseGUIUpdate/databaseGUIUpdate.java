package databaseGUIUpdate;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;



public class databaseGUIUpdate extends JFrame{
	  
	
		panelBuilder userInfoPanel;   // Panel for user information
		JPanel buttonPanel;                    // Panel for buttons
		JPanel listPanel;          // A panel to hold the scroll pane
		String searchString = "";   
		JScrollPane scrollPane;    // A scroll pane to hold the list
		JList nameList;
		JTable ourTable;
		String selectedValue;
		
		public databaseGUIUpdate()
		   {
		      // Set the window title.
		      setTitle("Update User");
		      
		      // Specify an action for the close button.
		      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		      
		      // Create a panelBuilder object.
		      userInfoPanel = new panelBuilder();
		      
		      // Build the buttonPanel object.
		      buildButtonPanel();
		      
		      // Build the listPanel object.
		      buildListPanel();
		      
		      // create a BorderLayout manager.
		      setLayout(new BorderLayout());
		      
		      // Add the panels to the content pane.
		      add(userInfoPanel, BorderLayout.NORTH);
		      add(listPanel, BorderLayout.CENTER);
		      add(buttonPanel, BorderLayout.SOUTH);
		      
		      // Pack and display the window.
		      pack();
		      setVisible(true);
		   }
		   
		   
		   private void buildListPanel()
		   {
		      try
		      {
		         // Create a panel.
		         listPanel = new JPanel();
		         
		         // Add a titled border to the panel.
		         listPanel.setBorder(BorderFactory.
		         createTitledBorder("User Information"));
		         //Create object to access database.
		         userTableManager getInfo = new userTableManager();
		         
		         //Create a resultset to hold the blank search for when the page starts
		         ResultSet userInfo = userTableManager.selectUsers("", "", "", null, "", "", "");
		         
		         //Uses the rs2XML code to create an object that will fill our jtable with the information 
			     ourTable = new JTable(DbUtils.resultSetToTableModel(userInfo));
			     //Scrollpane in case we have more records than we want to show up.
			     scrollPane = new JScrollPane(ourTable);
			     //Adds scrollPane to our listPanel
			     listPanel.add(scrollPane);
			     
			     //Listens in to what we click on in the table and gets the index value of that item.
			     ourTable.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
		                public void valueChanged(ListSelectionEvent event) {
		                	//Check to make sure table is not being reloaded
		                	if (ourTable.getSelectedRow() > 0) {
		                	//Gets ID value of row
		                    selectedValue = ourTable.getValueAt(ourTable.getSelectedRow(), 0).toString();
		                	}
		                }
		            });			         
		          }
		      catch(SQLException ex)
		      {
		         // If something goes wrong with the database, 
		         // display a message to the user.
		         JOptionPane.showMessageDialog(null, ex.toString());
		      }
		   }
		   /**
		      buildButtonPanel method
		    */
		   
		   private void buildButtonPanel()
		   {
		      // Create a panel for the buttons.
		      buttonPanel = new JPanel();
		      
		      // Create a Submit button and add an action listener.
		      JButton submitButton = new JButton("Submit");
		      submitButton.addActionListener(new SubmitButtonListener());
		      
		      // Create an Update button and add an action listener.
		      JButton updateButton = new JButton("Update");
		      updateButton.addActionListener(new UpdateButtonListener());
		      
		      // Create a Clear button and add an action listener.
		      JButton clearButton = new JButton("Clear");
		      clearButton.addActionListener(new ClearButtonListener());

		      // Create an Exit button.
		      JButton exitButton = new JButton("Exit");
		      exitButton.addActionListener(new ExitButtonListener());
		      
		      // Add the buttons to the panel.
		      buttonPanel.add(submitButton);
		      buttonPanel.add(updateButton);
		      buttonPanel.add(clearButton);
		      buttonPanel.add(exitButton);
		   }
		   
		   /**
		      Private inner class that handles Submit button events.
		    */
		   
		   private class SubmitButtonListener implements ActionListener
		   {
		      public void actionPerformed(ActionEvent e)
		      {
		        // Get the user information from the text fields.
		            String name = userInfoPanel.getName();
		            String address = userInfoPanel.getAddress();
		            String email = userInfoPanel.getEmail();
		            Double hr = userInfoPanel.getHR();
		            String city = userInfoPanel.getCity();
		            String state = userInfoPanel.getState();
		            String Zip = userInfoPanel.getZip();
		            //Parse value to double so it can be used in sql query
		            Double selValue = Double.parseDouble(selectedValue);
		     
		            userTableManager updater;
					try {
						//Create object and run update code in database
						updater = new userTableManager();
						updater.updateRecord(name, address, email, hr, selValue, city, state, Zip);
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
		            
					
					 //The code below is to requery the DB to get the updated info and output to the screen
		            ResultSet searchInfo = null;
		            
		            try {
		            	//Create an object to instantiate the Connection to the table
						userTableManager getInfo = new userTableManager();
						//This creates a blank search of the table
						searchInfo = getInfo.selectUsers("", "", "", null, "", "", "");
		            } catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		            //Resets the table to the new values
		            ourTable.setModel(DbUtils.resultSetToTableModel(searchInfo));
		      }
		   }
		   
		   /**
		      Private inner class that handles Update button events.
		    */
		   
		   private class UpdateButtonListener implements ActionListener
		   {
		      public void actionPerformed(ActionEvent e)
		      {
		    	  System.out.print(selectedValue);
		    	  try {
		    		  	ResultSet updateInfo = null;
		            	//Create an object to instantiate the Connection to the table
						userTableManager getInfo = new userTableManager();
						//This creates a blank search of the table
						updateInfo = userTableManager.selectUpdate(selectedValue);
						
						while (updateInfo.next()) {
							userInfoPanel.setName(updateInfo.getString("Name"));
							userInfoPanel.setAddress(updateInfo.getString("Address"));
							userInfoPanel.setEmail(updateInfo.getString("Email"));
							userInfoPanel.setHR(updateInfo.getDouble("Rate"));
							userInfoPanel.setCity(updateInfo.getString("City"));
							userInfoPanel.setState(updateInfo.getString("State"));
							userInfoPanel.setZip(updateInfo.getString("Zip"));
						}
		            } catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		      }
		   }
		   
		   /**
		      Private inner class that handles Clear button events.
		    */
		   
		   private class ClearButtonListener implements ActionListener
		   {
		      public void actionPerformed(ActionEvent e)
		      {
		    	  // Clears all the input boxes
		    	  userInfoPanel.clear();
		    	  
		    	  //We also want to clear the search criteria for what is showing up, so we create a
		    	  //resultset variable to hold a new blank search
		    	  ResultSet searchInfo = null;
		            
		            try {
		            	//Create an object to instantiate the Connection to the table
						userTableManager getInfo = new userTableManager();
						//This creates a blank search of the table
						searchInfo = userTableManager.selectUsers("", "", "", null, "", "", "");
		            } catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			        //Resets the table to the search criteria given above
		            ourTable.setModel(DbUtils.resultSetToTableModel(searchInfo));
		      }
		   }
		   
		   /**
		      Private inner class that handles Exit button events.
		    */
		   
		   private class ExitButtonListener implements ActionListener
		   {
		      public void actionPerformed(ActionEvent e)
		      {
		         // Exit the application.
		         System.exit(0);
		      }
		   }
		
		public static void main(String[] args) {
		// TODO Auto-generated method stub
			databaseGUIUpdate insertUser = new databaseGUIUpdate();
		}

}
