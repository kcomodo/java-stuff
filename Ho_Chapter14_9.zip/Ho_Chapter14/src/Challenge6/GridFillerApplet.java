package Challenge6;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/*
 * Quang Ho
 * 1/17/2021
 * Write an applet that displays a 4x4 grid.
 * User click on square, square displays circle
 * If circle is filled and user click on it again, circle disappear
 * PROBLEM:
 * Circle disappears when clicked on a different square
 * Can click outside of the square boxes to display circles
*/
public class GridFillerApplet extends JApplet
{
//
private int rows;
private int cols;
//x and y for the user
private int x;
private int y;
//gridRow and gridCol for the actual grid
//Could've somehow used an array to store the rows and cols to make it easier
private int gridRow;
private int gridCol;
//currentRow and currentCol when the user clicks on a square
private int currentRow;
private int currentCol;
/*
 * Initiate a method called init to create the grid
 * The gridFiller will create the grid by using the gridRow and gridCol 
 * The method will then call for the mouseListener function that uses the press option
 */
public void init()
{
  //GridFiller will create the grid by initializing a variable called createGrid
    GridFiller createGrid = new GridFiller();
    setContentPane(createGrid);
}

public class GridFiller extends JPanel
{
    GridFiller()
    {
    	//gridRow is created at -2 because if it were to be higher than -2, the circle would spawn directly
    	//on top of the first row
        gridRow = -2;
        //Create a mouseListener so when the user clicks or press on the squares, it would do something
        addMouseListener(new MyMouseListener());
    }


    public void paint(Graphics draw)
    {
    	//draw will be super
        super.paint(draw);
        //The rows and cols will be created using loops, couldve probably used an array of some sort for this
        for (rows = 0; rows < 4; rows++)
        {
            for (cols = 0; cols < 4; cols++)
            {
                x = rows * 50;
                y = cols * 50;
            //Made the squares black and white because none of the rectangles outlines are highlighted.
                if ((rows % 2) == (cols % 2))
                {
                    draw.setColor(Color.red);
                }
                //Rows will be colored green once red has been filled in
                else
                {
                    draw.setColor(Color.green);
                }
                //Fill the rectangles 
                draw.fillRect(x, y, 50, 50);
            }
        }

       //If the statement in mousePressed was true and that gridRow was not -1
       //The rectangle should be filled with a circle
        if(gridRow >= 0)
        {
        	//Fill the circle in with the color black
            draw.setColor(Color.black);
            //Positioned x and y in the square to fill in the circle
            x =	gridCol * 50;
            y = gridRow * 50;
            //Oval will be filled once the x and y are inserted 
            draw.fillOval(x, y, 50, 50);
        }
    }
}

public class MyMouseListener extends MouseAdapter
{
	//Could've used mouseClicked but it felt slower than mousePressed
	//mousePressed will highlight the squares that the user clicked on and turn it into a circle
	/*
	 * PROBLEM:
	 * When clicked on a circle, the circle appears as should be
	 * When clicked on the highlighted circle again, the circle disappears
	 * When clicked on a different square, the previous circle disappears.
	 */
    public void mousePressed(MouseEvent pressed)
    {
    	currentRow = pressed.getY() / 50;
        currentCol = pressed.getX() / 50;

     //If the circle was already in a square and the user clicks on it, the circle will disappear
     //gridRow will turn into -1 so that the circle can move off the board
        if(gridCol == currentCol &&  gridRow == currentRow)
        {
            gridRow = -1;
        }
        //If the above statement wasn't true, the circle will be filled inside the rectangle
        else
        {
        	gridCol = currentCol;
            gridRow = currentRow;
        }
        //Calling repaint to update the board so that the circle can appear
        repaint();

    }
}
}


