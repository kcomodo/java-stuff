package Challenge9;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



import java.io.File;
/*
 * Quang Ho
 * 1/17/2021
 * Create a java application that displays images on a slideshow
 * User will select images up to 10
 * Time delay should be added in
 * Time delay has to be in seconds
 * NOTE:
 * Application is based off of Professor Carman example for chapter 14 challenge 9
 */
public class SlideShow extends JFrame{
	//Created panels that holds images and buttons
    private JPanel PANEL_FOR_IMAGE;           
    private JPanel PANEL_FOR_BUTTON;        
    
    //Create a label for the image
    private JLabel LABEL_FOR_IMAGES;         
    /*
     * Create multiple buttons such as 
     * image button: to insert the images
     * delay button: to delay the time
     * start button: to start the slideshow
     * stop button: to stop the slideshow
     */
    private JButton BUTTON_FOR_IMAGES;        
    private JButton BUTTON_FOR_DELAY;       
    private JButton BUTTON_TO_START;        
    private JButton BUTTON_TO_STOP;   
    
    //Displays the current image
    private int imageCurrently = 0;  
    
    //Set a time delay in seconds
    private int timeDelay = 1500;   
    
    //Opens up the files to allow the user to insert images
    private JFileChooser fileChooser;    
    
    //Created a timer object
    private Timer timer;  
    
    //Stores in the amount of images that the application can hold, which is 10
    private final int imagesMax = 10;
    
    //Number of images the user has placed in
    private int NUMBER_OF_IMAGES = 0;       
    
    //Array that stores in the amount of images that the user has inserted in
    private ImageIcon[] imageStored;        
    
    public SlideShow()
    {
    	//Set the title as SlideShow Applications
         setTitle("SlideShow Application");

        //Allow the user to close the program
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Set the borderlayout as well as create the panel for the image and button
         setLayout(new BorderLayout());
		  buildImagePanel();
         buildButtonPanel();

         //Designate the location of the image panel and button panel
         add(PANEL_FOR_IMAGE, BorderLayout.CENTER);
         add(PANEL_FOR_BUTTON, BorderLayout.SOUTH);

         //Initialize the fileChooser
         fileChooser = new JFileChooser(".");
         
         //New function that uses the TimeListener, this will add in a delay to the application when
         //Displaying images
         timer = new Timer(timeDelay, new TimerListener());
         
         //Stores in the images from the amount of images inserted
         imageStored = new ImageIcon[imagesMax];

         
         pack();
         //Set visible is just to make the application appear
         setVisible(true);
    }

    //buildImagePanel method will create the panels and labels for the images
    private void buildImagePanel()
    {
         //Creates the image panel and image label
         PANEL_FOR_IMAGE = new JPanel();
         LABEL_FOR_IMAGES = new JLabel();
         
         //Add in the image label on the image panel
         PANEL_FOR_IMAGE.add(LABEL_FOR_IMAGES);
    }

    //Created a method to build the button panels
    private void buildButtonPanel()
    {
    	//Create a button panel
         PANEL_FOR_BUTTON = new JPanel();

         //imageBitton will allow users to open their files and insert images
         BUTTON_FOR_IMAGES = new JButton("Add Image");
         BUTTON_FOR_IMAGES.setMnemonic(KeyEvent.VK_A);
         BUTTON_FOR_IMAGES.setToolTipText("Click here to add an image.");
         
         //delayButton will allow the user to delay the time between each images 
         BUTTON_FOR_DELAY = new JButton("Set Time Delay");
         BUTTON_FOR_DELAY.setMnemonic(KeyEvent.VK_T);
         BUTTON_FOR_DELAY.setToolTipText("Click here to set the time delay.");

         //startButton will start the slideshow
         BUTTON_FOR_DELAY = new JButton("Start");
         BUTTON_FOR_DELAY.setMnemonic(KeyEvent.VK_S);
         BUTTON_TO_START.setToolTipText("Click here to start the slide show.");
  
         //stopButton will stop the slideshow
         BUTTON_TO_STOP = new JButton("Stop");
         BUTTON_TO_STOP.setMnemonic(KeyEvent.VK_P);
         BUTTON_TO_STOP.setToolTipText("Click here to stop the slide show.");

         //Add in actionListener for each one of the buttons for the user to interact with
         BUTTON_FOR_IMAGES.addActionListener(new ImageButtonListener());
         BUTTON_FOR_DELAY.addActionListener(new DelayButtonListener());
         BUTTON_TO_START.addActionListener(new StartButtonListener());
         BUTTON_TO_STOP.addActionListener(new StopButtonListener());
         
         //Add in the panels for the buttons: image, delay, start, and stop
         PANEL_FOR_BUTTON.add(BUTTON_FOR_IMAGES);
         PANEL_FOR_BUTTON.add(BUTTON_FOR_DELAY);
         PANEL_FOR_BUTTON.add(BUTTON_TO_START);
         PANEL_FOR_BUTTON.add(BUTTON_TO_STOP);
    }

    

    private class ImageButtonListener implements ActionListener
    {
    

         public void actionPerformed(ActionEvent e)
         {
        	 //File allows the user to select the files
              File selectedFile;
             //It will then read the image that the user has selected
              ImageIcon thisImage; 
              //filename will hold the name and path of the file
              String filename;       
           // Indicates status of the open dialog box
              int fileChooserStatus; 
              //Create an if statement if the max amount of images has been selected
              //If there are 10 images, the application will display a message
              if (NUMBER_OF_IMAGES >= imagesMax)
                 JOptionPane.showMessageDialog(null, "The maximum number of images " +
                                                     "have been selected.");
              else
              {              
    
                 fileChooserStatus = fileChooser.showOpenDialog(SlideShow.this);

                 if (fileChooserStatus == JFileChooser.APPROVE_OPTION)
                 {
    
                   selectedFile = fileChooser.getSelectedFile();

    
                   filename = selectedFile.getPath();

    
                   thisImage = new ImageIcon(filename);

    
                   imageStored[NUMBER_OF_IMAGES] = thisImage;
                   NUMBER_OF_IMAGES++;
                 }
              }
         }
    }

  

  private class DelayButtonListener implements ActionListener
  {
     //The delay method will allow the user to delay the time for the slideshow
	 //It will prompt a message asking the user to enter a time (in seconds)
     public void actionPerformed(ActionEvent e)
     {
        String input = JOptionPane.showInputDialog("Enter the time delay (in seconds).");
        timeDelay = Integer.parseInt(input) * 1000;
        //The time will be set based on the user input
        timer.setDelay(timeDelay);
     }
  }
  
 
  
  private class StartButtonListener implements ActionListener
  {
	  //The start method will start the slideshow
     public void actionPerformed(ActionEvent e)
     {
        timer.start();
     }
  }

  
  private class StopButtonListener implements ActionListener
  {
     //The stop method will stop the slideshow
  
     public void actionPerformed(ActionEvent e)
     {
        timer.stop();
     }
  }

  
  
  private class TimerListener implements ActionListener
  {
    
  //The timerListener will display the images
	  //The image will switch places whenever the slide changes
     public void actionPerformed(ActionEvent e)
     {
    	 //When image is display, set the title as image and display images
        setTitle("Image: " + String.valueOf(imageCurrently+1));  
        LABEL_FOR_IMAGES.setIcon(imageStored[imageCurrently]);        
        pack();
        if (imageCurrently < (NUMBER_OF_IMAGES - 1))
           imageCurrently++;
        else
           imageCurrently = 0;
     }
  }

  /*
     Call out the main method to display the application
  */
  public static void main(String[] args)
  {
     SlideShow slideshow = new SlideShow();
  }
}