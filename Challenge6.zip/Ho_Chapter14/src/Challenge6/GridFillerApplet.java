package Challenge6;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class GridFillerApplet extends JApplet{
	int currentX;
	int currentY;
	public void init() {
		addMouseListener(new MyMouseListener());
		
	}
	public void paint(Graphics Draw) {
		super.paint(Draw);
		//Creating a box to store in the smaller squares
		Draw.drawRect(600, 100,400,400);
			//First row
			Draw.drawRect(600, 100, 100, 100);
		    Draw.drawRect(700, 100, 100, 100);
		    Draw.drawRect(800, 100, 100, 100);
		    Draw.drawRect(900, 100, 100, 100);
		//Second Row
		    Draw.drawRect(600, 200, 100, 100);
		    Draw.drawRect(700, 200, 100, 100);
		    Draw.drawRect(800, 200, 100, 100);
		    Draw.drawRect(900, 200, 100, 100);
		    
		//Third Row
		    Draw.drawRect(600, 300, 100, 100);
		    Draw.drawRect(700, 300, 100, 100);
		    Draw.drawRect(800, 300, 100, 100);
		    Draw.drawRect(900, 300, 100, 100);
		    
		//Fourth Row    
		    Draw.drawRect(600, 400, 100, 100);
		    Draw.drawRect(700, 400, 100, 100);
		    Draw.drawRect(800, 400, 100, 100);
		    Draw.drawRect(900, 400, 100, 100);
		    
		    Draw.drawOval(currentX,currentY,50,50);
	}
	
	private class MyMouseListener extends MouseAdapter
	{	
		//When clicked on, display a circle
		//If the square is already filled with a circle, remove it
		public void mouseClicked(MouseEvent clicked) {
			int currentX = clicked.getX();
			int currentY = clicked.getY();
			
			repaint();
		}
	}




}
