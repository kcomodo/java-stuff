package databaseGUIInsert;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
   The userTableManager class provides methods for 
   inserting a record into the user table of the 
   testdbgui database.
*/

public class userTableManager
{
   // Create a named constant for the URL.
   // NOTE: This value is specific for Java DB
   public final String DB_URL = 
                "jdbc:ucanaccess://coffeedb.accdb";

   // Field for the database connection
   private Connection conn;

   /**
      Constructor
    */
   
   public userTableManager() throws SQLException
   {
      // Create a connection to the database.
      conn = DriverManager.getConnection(DB_URL);
   }
   
   public void insert(int number,String name, String address, String city, String state, String zip) 
                      throws SQLException
   {
     
	   String ourSQLInsert = "INSERT INTO customers (dbcustnum, dbcustname, dbcustaddress, dbcustcity, dbcuststate, dbcustzip)"
	   		+  "VALUES (?, ?, ?, ?, ?, ?)";  
                     
	   // Create a Statement object.
	   PreparedStatement prepStmt = conn.prepareStatement(ourSQLInsert);

	   //Statement to insert our variables into the prepared sql placeholders.  Number is the position
	   //that the question mark is at above, starting at one.  Variable types matter
	   prepStmt.setInt(1, number);
	   prepStmt.setString(2, name);
	   prepStmt.setString(3, address);
	   prepStmt.setString(4, city);
	   prepStmt.setString(5, state);
	   prepStmt.setString(6, zip);
	   

	   //Executes the query, note that the command is slightly different than select, due to the fact that
	   //no results are being returned
	   prepStmt.executeUpdate();
	   prepStmt.close();
   }
}