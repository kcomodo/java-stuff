import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.JOptionPane;

import javax.swing.*;
/*
 * Final Project
 * Quang Ho
 * 12/9/2020
 * Tic Tac Toe UPDATED
 * Tic tac toe will be played with 2 players
 */
public class TicTacToeUpdated extends JFrame implements ActionListener{
	//Create the variables
	//Player turn will be boolean to check which player goes first
	//Add in panel button and label button
	//board button will have 9 buttons since it has 9 blocks on a tic tac toe board
	boolean playerTurn;
	JPanel panelButton = new JPanel();
	JButton[] boardButtons = new JButton[9];
	//Add in the frame
	//Random will decide which player goes first
	JFrame gameFrame = new JFrame();
	Random rand = new Random();


	
	//Create the board layout
	TicTacToeUpdated(){
		//Set title
		setTitle("Tic Tac Toe");
		//Set board width and size
		gameFrame.setSize(400,400);
		//Set the visibility to true
		gameFrame.setVisible(true);

		panelButton.setLayout(new GridLayout(3,3));
		//Game will close on exit
		gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Create the board
		//Has 9 blocks
		//Set each block as a button for user to click on
		for(int i=0;i<9;i++) {
			boardButtons[i] = new JButton();
			panelButton.add(boardButtons[i]);
			boardButtons[i].setFocusable(false);
			boardButtons[i].addActionListener((ActionListener) this);

		}
		//Add in the buttons for the board
		gameFrame.add(panelButton);

		//Call for the turn method
		firstTurn();
	}
	//When player 1 clicks on board
	//Place down an X
	//Check to see if X or Y has won each time
	public void actionPerformed(ActionEvent e) {
		for(int a=0;a<9;a++) {
			if(e.getSource()==boardButtons[a]) {
				if(playerTurn) {
					if(boardButtons[a].getText()=="") {
						boardButtons[a].setText("X");
						playerTurn=false;
		

						checkWinner();

					}

				}
				//Same with player 2, place down Y
				else {

					if(boardButtons[a].getText()=="") {
						boardButtons[a].setText("O");
						playerTurn=true;
			
						checkWinner();

					}

				}

			}			

		}

	}
	//X will go first if chosen
	//Same with Y
	public void firstTurn() {
		if(rand.nextInt(2)==0) {
			playerTurn=true;
		
		}

		else {
			playerTurn=false;
		
		}

	}
	//Check winner will check each board to see if they allign
	//Using the If method, check each individual buttons on the board
	//If player X has won, call the xWon method
	//If player Y has won, call the yWon method
	public void checkWinner() {
		if(

				(boardButtons[0].getText()=="X") &&

				(boardButtons[1].getText()=="X") &&

				(boardButtons[2].getText()=="X")

				) {

			xWon(0,1,2);
		}

		if(

				(boardButtons[3].getText()=="X") &&

				(boardButtons[4].getText()=="X") &&

				(boardButtons[5].getText()=="X")

				) {

			xWon(3,4,5);

		}

		if(

				(boardButtons[6].getText()=="X") &&

				(boardButtons[7].getText()=="X") &&

				(boardButtons[8].getText()=="X")

				) {

			xWon(6,7,8);

		}

		if(

				(boardButtons[0].getText()=="X") &&

				(boardButtons[3].getText()=="X") &&

				(boardButtons[6].getText()=="X")

				) {

			xWon(0,3,6);

		}

		if(

				(boardButtons[1].getText()=="X") &&

				(boardButtons[4].getText()=="X") &&

				(boardButtons[7].getText()=="X")

				) {

			xWon(1,4,7);

		}

		if(

				(boardButtons[2].getText()=="X") &&

				(boardButtons[5].getText()=="X") &&

				(boardButtons[8].getText()=="X")

				) {

			xWon(2,5,8);

		}

		if(

				(boardButtons[0].getText()=="X") &&

				(boardButtons[4].getText()=="X") &&

				(boardButtons[8].getText()=="X")

				) {

			xWon(0,4,8);

		}

		if(

				(boardButtons[2].getText()=="X") &&

				(boardButtons[4].getText()=="X") &&

				(boardButtons[6].getText()=="X")

				) {

			xWon(2,4,6);

		}
		if(

				(boardButtons[0].getText()=="O") &&

				(boardButtons[1].getText()=="O") &&

				(boardButtons[2].getText()=="O")

				) {

			oWon(0,1,2);
		}

		if(

				(boardButtons[3].getText()=="O") &&

				(boardButtons[4].getText()=="O") &&

				(boardButtons[5].getText()=="O")

				) {

			oWon(3,4,5);

		}

		if(

				(boardButtons[6].getText()=="O") &&

				(boardButtons[7].getText()=="O") &&

				(boardButtons[8].getText()=="O")

				) {

			oWon(6,7,8);

		}

		if(

				(boardButtons[0].getText()=="O") &&

				(boardButtons[3].getText()=="O") &&

				(boardButtons[6].getText()=="O")

				) {

			oWon(0,3,6);

		}

		if(

				(boardButtons[1].getText()=="O") &&

				(boardButtons[4].getText()=="O") &&

				(boardButtons[7].getText()=="O")

				) {

			oWon(1,4,7);

		}

		if(

				(boardButtons[2].getText()=="O") &&

				(boardButtons[5].getText()=="O") &&

				(boardButtons[8].getText()=="O")

				) {

			oWon(2,5,8);

		}

		if(

				(boardButtons[0].getText()=="O") &&

				(boardButtons[4].getText()=="O") &&

				(boardButtons[8].getText()=="O")

				) {

			oWon(0,4,8);

		}

		if(

				(boardButtons[2].getText()=="O") &&

				(boardButtons[4].getText()=="O") &&

				(boardButtons[6].getText()=="O")

				) {

			oWon(2,4,6);

		}

	}

	
	//If X has won, display the block that were alligned with the color white
	
	public void xWon(int a,int b,int c) {

		boardButtons[a].setBackground(Color.WHITE);

		boardButtons[b].setBackground(Color.WHITE);

		boardButtons[c].setBackground(Color.WHITE);

		

		for(int o=0;o<9;o++) {

			boardButtons[o].setEnabled(false);

		}
		//Displays a message if X has won
		JOptionPane.showMessageDialog(null, "X wins");

		//If Y has won, display the block that were alligned with the color white
	}

	public void oWon(int a,int b,int c) {

		boardButtons[a].setBackground(Color.WHITE);

		boardButtons[b].setBackground(Color.WHITE);

		boardButtons[c].setBackground(Color.WHITE);

		

		for(int i=0;i<9;i++) {

			boardButtons[i].setEnabled(false);

		}
		//Displays a message saying Y has won
		JOptionPane.showMessageDialog(null, "Y wins");


	}
	/*
	 * Main
	 * Use to start the game
	 * Named it as run
	 */
	   public static void main(String[] args)
	   {
	      TicTacToeUpdated run = new TicTacToeUpdated();
	   }

}
