import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class fileCrypt {

	public static void encryptFile(String existing, String encrypted) throws IOException  {
		boolean eof = false;
		
		FileInputStream inStream = new FileInputStream(existing);
		DataInputStream inFile = new DataInputStream(inStream);
		FileOutputStream outStream = new FileOutputStream(encrypted);
		DataOutputStream outFile = new DataOutputStream(outStream);
		/*
		 * Read the first file one character at a time
		 * Encrypt it by adding 15 to each characters
		 * Output it to the second file
		 */
		while(!eof) {
			try {
				byte input = inFile.readByte();
				input+=15;
				outFile.writeByte(input);
			}
			catch(EOFException e) {
				eof = true;
			}
		}
		inFile.close();
		outFile.close();
	}
		
	public static void decryptFile(String existing, String decrypted) throws IOException {
		/*
		 * Open the second file
		 * Read the file
		 * Create a third file
		 * Decrypt the second file 
		 * Transfer the information onto the third txt file
		 */
		boolean eof = false;
		
		FileInputStream inStream = new FileInputStream(existing);
		DataInputStream inFile = new DataInputStream(inStream);
		FileOutputStream outStream = new FileOutputStream(decrypted);
		DataOutputStream outFile = new DataOutputStream(outStream);
		/*
		 * Read the first file one character at a time
		 * Decrypt it by subtracting 10 to each characters
		 * Output it to the third file
		 */
		while(!eof) {
			try {
				byte input = inFile.readByte();
				input-=15;
				outFile.writeByte(input);
			}
			catch(EOFException e) {
				eof = true;
			}
		}
		inFile.close();
		outFile.close();
	}
}


