/*
 * This class extends to the advancedUser
 * This program will store the permission level information 
 */
public class superUser extends advancedUser{
	private String permission;
	public superUser(String personName, String personEmail, int hoursWorked, int hourlyRate, boolean inRange,
			boolean raterange, String permissionLevel) {
		super(personName, personEmail, hoursWorked, hourlyRate, inRange, raterange);
		this.permission = permissionLevel;
	}
	public String getPermission() {
		return permission;
	}
	public void setPermission() {
		this.permission = permission;
	}
}
