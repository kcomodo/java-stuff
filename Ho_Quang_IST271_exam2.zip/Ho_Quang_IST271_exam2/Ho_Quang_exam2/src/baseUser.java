/*
 * Stores the user name and their email
 * advancedUser will extend to this class
 */
public class baseUser {
	private String name, email;
	public baseUser(String personName, String personEmail) {
		this.name = personName;
		this.email = personEmail;
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public void setName() {
		this.name = name;
	}
	public void setEmail() {
		this.email = email;
	}
}
