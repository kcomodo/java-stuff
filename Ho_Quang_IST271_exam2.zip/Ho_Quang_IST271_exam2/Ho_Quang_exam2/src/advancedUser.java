/*
 * Extends to baseUser
 * Stores the following information
 * The user hours, and their hourly rate
 * The program will decide if they worked over the required time or below it
 * It will also decide if the hourly rate is over or under the requirements
 */
public class advancedUser extends baseUser{
	private int hours, rate;
	private boolean range, rateRange;
	public advancedUser(String personName, String personEmail, int hoursWorked, int hourlyRate, boolean inRange, boolean raterange) {
		super(personName, personEmail);
		this.hours = hoursWorked;
		this.rate = hourlyRate;
	}
	public int getHours() {
		return hours;
	}
	public boolean getRange() {
		if(hours < 0 || hours > 80) {
			return false;
		}
		return true;
	}
	public int getRate() {
		return rate;
	}
	public boolean getRateRange() {
		if(rate < 10 || rate > 42.50) {
			return false;
		}
		return true;
	}
	

}
