import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileWriter;
import java.util.Scanner;
import java.io.IOException;
public class mainClass {
/*
 * Quang Ho
 * IST 271 Exam 2
 * Main program
 * This program will ask the user to enter their name, email, amount of hours they worked, and their hourly rate
 * The program will then ask for the user permission level
 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your name: ");
		String personName = scanner.nextLine();
		
		System.out.println("Enter your email: ");
		String personEmail = scanner.nextLine();
		
		System.out.println("Enter the amount of hours you've worked: ");
		int hoursWorked = scanner.nextInt();
		
		System.out.println("Enter your hourly rate: ");
		int hourlyRate = scanner.nextInt();
		boolean inRange = false;
		boolean rateRange = false;
		
		System.out.println("Enter your permission level: ");
		String permissionLevel = scanner.next();
		//Encrypt the file into "myFile"
		//Decrypt the file into "myPermit.txt"
		try {
			FileWriter myWriter = new FileWriter("myFile");
	        myWriter.write(permissionLevel);
	        myWriter.close();
	        System.out.println("Successfully wrote to the file.");
		} catch (Exception e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
		}
		//superUser will extend to advancedUser which is extended to baseUser
		superUser superuser = new superUser(personName, personEmail, hoursWorked, hourlyRate, inRange, rateRange, permissionLevel);
		
		/*
		 * Program will print out the following information:
		 * The user name, their email, hours worked, and hourly rate
		 */
		System.out.println("Hello "+superuser.getName());
		System.out.println("Your email is: "+ superuser.getEmail());
		System.out.println("The amount of hours you've worked: "+superuser.getHours());
		System.out.println("In range of hours worked: "+ superuser.getRange());
		System.out.println("Your hourly rate: "+ superuser.getRate());
		System.out.println("In range of hourly rate: "+superuser.getRateRange());

		//The program will encrypt the permission level and then decrypt it
		System.out.println("We are encrypting your files...");
		try {
			fileCrypt.encryptFile("myFile", "Encrypted.txt");
			System.out.println("All done, you are secured");
		}
		catch (IOException e) {
			System.out.println("Error" + e.getMessage());
		}
		System.out.println("We are decrypting your file");
		try {
			fileCrypt.decryptFile("Encrypted.txt","myPermit.txt");
		}
		catch(IOException e) {
			System.out.println("Error" + e.getMessage());
		}


	}

}
