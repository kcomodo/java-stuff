import java.util.Scanner;
/*
 * This class creates a dice and rolls it randomly  
 * The dice will roll for the user and computer
 */
import java.util.Random;
public class theDie {
	public int USER_ROLL;
	public int COMPUTER_ROLL;
	public int user_turn() {
		return USER_ROLL;
	}
	public int computer_turn() {
		return COMPUTER_ROLL;
	}
}
