/*
 * This class is to create the car for the user
 */
public class theCar {
	public String car1;
	public String createCar() {
		return car1;
	}
}
