/*
 * Quang Ho
 * Exam 1
 * 9/27/2020
 * This is the main class
 * 3 other classes are connected to this class
 * userAccount, theDie, theCar
 */
import java.util.Scanner;
import java.util.Random;
public class exam1 {

	public static void main(String[] args) {
		/*
		 * Create variables for the user and computer for cars, spaces, and rolls
		 * Create a class for the user to enter a username and password
		 * Create a class for the user to create a car
		 * Ask the user how many rounds they would like to play
		 * Ask the user how many spaces they want their car to move to reach the finish line
		 */
		String userName;
		String passWord;
		int numRounds;
		int spaces;
		int spaceCount = 0;
		int spaceCount2 = 0;
		int roundsCount = 1;
		String userInput;
		int computerRoll = 0;
		int userRoll = 0;
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter a username: ");
		userName = keyboard.nextLine();
		String userCar = userName;
		System.out.println("Enter a password: ");
		passWord = keyboard.nextLine();
		userAccount user = new userAccount();
		user.USER_NAME = userName;
		user.PASS_WORD = passWord;
		System.out.println(user.verify());
		
		System.out.println("How many rounds would you like to play? ");
		numRounds = keyboard.nextInt();
		System.out.println("How many spaces would you like for the car to move to reach the finish line? ");
		spaces = keyboard.nextInt();
		
		System.out.println("Hello "+userName);
		System.out.println("Enter R to move your car, enter P to park your car and not move, enter L to get the location of your car");
			theCar car = new theCar();
			car.car1 = userCar;
			System.out.println("Your car has been created");
			/*
			 * Import a random function
			 * Ask the user to enter R, P, or L
			 * R to roll and move their car
			 * P to park the car
			 * L to display the car location
			 */
			while(roundsCount < numRounds) {
				Random rand = new Random();
				userRoll = rand.nextInt(6)+1;
				Random rand2 = new Random();
				computerRoll = rand2.nextInt(6)+1;
				theDie die = new theDie();
				die.USER_ROLL = userRoll;
				die.COMPUTER_ROLL = computerRoll;
				System.out.println("Your dice has been rolled");
				System.out.println("Enter R, P or L");
				userInput = keyboard.nextLine();
				if(userInput.contains("R") || userInput.contains("r")) {
					spaceCount += userRoll;
					spaceCount2 += computerRoll;
					System.out.println("Your car has been moved");
				}
				else if(userInput.contains("P") || userInput.contains("p")) {
					spaceCount+=0;
					spaceCount2+=computerRoll;
					System.out.println("Your car has been parked");
				}
				else if(userInput.contains("L") || userInput.contains("l")) {
					System.out.println("Your car has moved "+spaceCount+" spaces");
					System.out.println("The computer has moved "+ spaceCount2+" spaces");
				}
				if(spaceCount >= spaces) {
					System.out.println("You win!");
				}
				else if(spaceCount2 >= spaces) {
					System.out.println("The computer wins!");
					
				}
				else if(spaceCount >= spaces && spaceCount2 >= spaces) {
					System.out.println("Tie!");
				}
				roundsCount++;
				/*
				 * At the end of the game
				 * display the user car location and the computer car location
				 * display the winner
				 */
			}
			if(spaceCount > spaceCount2) {
				System.out.println("You win!");
				System.out.println("Your car has moved "+spaceCount+" spaces");
				System.out.println("The computer has moved "+spaceCount2+" spaces");
			}
			else if(spaceCount < spaceCount2) {
				System.out.println("Computer wins!");
				System.out.println("Your car has moved "+spaceCount+" spaces");
				System.out.println("The computer has moved "+spaceCount2+" spaces");
			}
			else if(spaceCount == spaceCount2) {
				System.out.println("Tie!");
				System.out.println("Your car has moved "+spaceCount+" spaces");
				System.out.println("The computer has moved "+spaceCount2+" spaces");
			}


	}

}
