/*
 * This class will verify the username and password for the user
 * If the username is shorter than 5, notify the user that it's too short
 * Same with the password, if the password is shorter than 7, notify the user
 * The password requires 3 uppercases, 2 uppercases, and 2 digits
 */
public class userAccount {
	 public String USER_NAME;
	 public String PASS_WORD;
	 public String verify() {
		 if(USER_NAME.length() < 5) {
			 return "Username is too short";
		 }
		 else if(PASS_WORD.length() < 7) {
			 return "Password is too short";
		 }
		 int i = 0;
		 int upperCaseCount = 0;
		 int lowerCaseCount = 0;
		 int digitCount = 0;
		 while(i < PASS_WORD.length()) {
			 char userPassword = PASS_WORD.charAt(i);
			 if(Character.isUpperCase(userPassword)) {
				 upperCaseCount+=1;
			 }
			 else if(Character.isLowerCase(userPassword)) {
				 lowerCaseCount+=1;
			 }
			 else if(Character.isDigit(userPassword)) {
				 digitCount+=1;
			 }
			 i++;
		 }
		 if(upperCaseCount >= 3 && lowerCaseCount >= 2 && digitCount >= 2) {
			 return "Username and Password is valid";
		 }
		 else {
			 return "The password or username is invalid";
		 }
	 }
	 
}
