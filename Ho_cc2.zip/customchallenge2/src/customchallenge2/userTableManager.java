package customchallenge2;

import java.sql.*;


public class userTableManager
{
   // Create a named constant for the URL.
   // NOTE: This value is specific for Java DB
   public final String DB_URL = 
                "jdbc:ucanaccess://customchal.accdb";

   // Field for the database connection
   private static Connection conn;

   /**
      Constructor
    */
   
   public userTableManager() throws SQLException
   {
      // Create a connection to the database.
      conn = DriverManager.getConnection(DB_URL);
   }
   
   public void insertEmployees(String empName, String empCity, String empState, String empZip, String empPhone, String empNDA) 
           throws SQLException
{

String ourSQLInsert = "INSERT INTO employees (empName, empCity, empState, empZip, empPhone, NDA)"
	+  "VALUES (?, ?, ?, ?, ?, ?)"; 
String ourLocationInsert = "Insert INTO location (empName)"+ "VALUES (?, ?)";
          
// Create a Statement object.
PreparedStatement prepStmt = conn.prepareStatement(ourSQLInsert);
PreparedStatement prepLocationStmt = conn.prepareStatement(ourLocationInsert);
//Statement to insert our variables into the prepared sql placeholders.  Number is the position
//that the question mark is at above, starting at one.  Variable types matter
prepStmt.setString(1, empName);
prepStmt.setString(2, empCity);
prepStmt.setString(3, empState);
prepStmt.setString(4, empZip);
prepStmt.setString(5, empPhone);
prepStmt.setString(6, empNDA);
prepLocationStmt.setString(2, empName);



//Executes the query, note that the command is slightly different than select, due to the fact that
//no results are being returned
prepStmt.executeUpdate();
prepStmt.close();
}
}