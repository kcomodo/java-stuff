package customchallenge2;

import javax.swing.*;
import java.awt.*;

public class panelBuilder extends JPanel
{
	
   //Employee Fields
   private JTextField empNameTextField;      
   private JTextField empCityTextField;   
   private JTextField empStateTextField;  
   private JTextField empZipTextField;  
   private JTextField empPhoneTextField;      
   private JTextField NDATextField;      

   
   public panelBuilder()
   {
      //Employee Information
	  JLabel empNamePrompt = new JLabel("Employee Name");
	  empNameTextField = new JTextField(45);
	  JLabel empCityPrompt = new JLabel("Employee City");
	  empCityTextField = new JTextField(45);
	  JLabel empStatePrompt = new JLabel("Employee State");
	  empStateTextField = new JTextField(45);
	  JLabel empZipPrompt = new JLabel("Employee Zip");
	  empZipTextField = new JTextField(5);
	  JLabel empPhonePrompt = new JLabel("Employee Phone");
	  empPhoneTextField = new JTextField(10);
	  JLabel empNDAPrompt = new JLabel("Nurse, Doctor, or Admin");
	  NDATextField = new JTextField(45);
	  
	  

    
      setLayout(new GridLayout(12, 1));   
      setBorder(BorderFactory.createTitledBorder("Enter Employees Information"));

      add(empNamePrompt);
      add(empNameTextField);
      
      add(empCityPrompt);
      add(empCityTextField);
      
      add(empStatePrompt);
      add(empStateTextField);
      
      add(empZipPrompt);
      add(empZipTextField);
      
      add(empPhonePrompt);
      add(empPhoneTextField);
      
      add(empNDAPrompt);
      add(NDATextField);
      

   }
   
   public String getEmpName()
   {
      return empNameTextField.getText();
   }
   
   public String getEmpState()
   {
      return empStateTextField.getText();
   }
   
   public String getEmpCity()
   {
      return empCityTextField.getText();
   }
   public String getEmpZip()
   {
      return empZipTextField.getText();
   }
   public String getEmpPhone()
   {
      return empPhoneTextField.getText();
   }
   public String getEmpNDA()
   {
      return NDATextField.getText();
   }
   

   public void clear()
   {
      empNameTextField.setText("");
      empStateTextField.setText("");
      empCityTextField.setText("");
      empZipTextField.setText("");
      empPhoneTextField.setText("");
      NDATextField.setText("");
   }
}
