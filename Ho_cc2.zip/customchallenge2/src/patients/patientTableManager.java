package patients;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class patientTableManager
{
   // Create a named constant for the URL.
   // NOTE: This value is specific for Java DB
   public final String DB_URL = 
                "jdbc:ucanaccess://customchal.accdb";

   // Field for the database connection
   private static Connection conn;

   /**
      Constructor
    */
   
   public patientTableManager() throws SQLException
   {
      // Create a connection to the database.
      conn = DriverManager.getConnection(DB_URL);
   }
   
   public void insertPatients(String patLastName, String patFirstName, String patPhone, String patCity, String patState, String patZip) 
           throws SQLException
{

String ourSQLInsert = "INSERT INTO patients (lastName, firstName, phoneNumber, patCity, patState, patZip)"
	+  "VALUES (?, ?, ?, ?, ?, ?)";  
          
// Create a Statement object.
PreparedStatement prepStmt = conn.prepareStatement(ourSQLInsert);

//Statement to insert our variables into the prepared sql placeholders.  Number is the position
//that the question mark is at above, starting at one.  Variable types matter
prepStmt.setString(1, patLastName);
prepStmt.setString(2, patFirstName);
prepStmt.setString(3, patPhone);
prepStmt.setString(4, patCity);
prepStmt.setString(5, patState);
prepStmt.setString(6, patZip);



//Executes the query, note that the command is slightly different than select, due to the fact that
//no results are being returned
prepStmt.executeUpdate();
prepStmt.close();
}
}
