package patients;

import javax.swing.*;
import java.awt.*;

public class patientPanelBuilder extends JPanel
{
	
   //Employee Fields
   private JTextField patLastNameTextField;    
   private JTextField patFirstNameTextField;      
   private JTextField patCityTextField;   
   private JTextField patStateTextField;  
   private JTextField patZipTextField;  
   private JTextField patPhoneTextField;      
     

   
   public patientPanelBuilder()
   {
      //Employee Information
	  JLabel patLastNamePrompt = new JLabel("Patient Last Name");
	  patLastNameTextField = new JTextField(45);
	  JLabel patFirstNamePrompt = new JLabel("Patient First Name");
	  patFirstNameTextField = new JTextField(45);
	  JLabel patCityPrompt = new JLabel("Patient City");
	  patCityTextField = new JTextField(45);
	  JLabel patStatePrompt = new JLabel("Patient State");
	  patStateTextField = new JTextField(45);
	  JLabel patZipPrompt = new JLabel("Patient Zip");
	  patZipTextField = new JTextField(5);
	  JLabel patPhonePrompt = new JLabel("Patient Phone");
	  patPhoneTextField = new JTextField(10);

	  
	  

    
      setLayout(new GridLayout(12, 1));   
      setBorder(BorderFactory.createTitledBorder("Enter Patient Information"));

      add(patLastNamePrompt);
      add(patLastNameTextField);
      
      add(patFirstNamePrompt);
      add(patFirstNameTextField);
      
      add(patCityPrompt);
      add(patCityTextField);
      
      add(patStatePrompt);
      add(patStateTextField);
      
      add(patZipPrompt);
      add(patZipTextField);
      
      add(patPhonePrompt);
      add(patPhoneTextField);

      

   }
   
   public String getPatLastName()
   {
      return patLastNameTextField.getText();
   }
   public String getPatFirstName()
   {
      return patLastNameTextField.getText();
   }
   
   public String getPatState()
   {
      return patStateTextField.getText();
   }
   
   public String getPatCity()
   {
      return patCityTextField.getText();
   }
   public String getPatZip()
   {
      return patZipTextField.getText();
   }
   public String getPatPhone()
   {
      return patPhoneTextField.getText();
   }

   

   public void clear()
   {
      patLastNameTextField.setText("");
      patFirstNameTextField.setText("");
      patStateTextField.setText("");
      patCityTextField.setText("");
      patZipTextField.setText("");
      patPhoneTextField.setText("");
 
   }
}