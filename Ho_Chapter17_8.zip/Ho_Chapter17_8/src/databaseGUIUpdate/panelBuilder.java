package databaseGUIUpdate;

import javax.swing.*;
import java.awt.*;

/**
   The panelBuilder class builds a panel containing the 
   labels and text fields for inserting data into the user
   table of the testdbgui database.
*/

public class panelBuilder extends JPanel
{
   private JTextField nameTextField;      // name
   private JTextField positionTextField;     // email
   private JTextField hrTextField;       // hourly rate 
   
   public panelBuilder()
   {
      // Create labels and text fields
      // for the user data.
      
      JLabel namePrompt = new JLabel("Employee Name");
      nameTextField = new JTextField(45);
      
      
      JLabel positionPrompt = new JLabel("Employee Position");
      positionTextField = new JTextField(45);
      
      JLabel hrPrompt = new JLabel("Hourly Rate");
      hrTextField = new JTextField(10);
      
      // Create a grid layout manager 
      // with 12 rows and 1 column.
      setLayout(new GridLayout(12, 1));   
      setBorder(BorderFactory.createTitledBorder("Enter User Information"));
      
      // Add the labels and text fields
      // to the panel.
      
      add(namePrompt);
      add(nameTextField);
      
      add(positionPrompt);
      add(positionTextField);
      
      
      add(hrPrompt);
      add(hrTextField);
   }
   
	   /**
	   The setName method sets the 
	   name entered by the user.
	 */
	
	public void setName(String name)
	{
		nameTextField.setText(name);
	}

	   /**
	   The setAddress method sets the 
	   address entered by the user.
	 */
	
	  public void setPosition(String position) {
		  positionTextField.setText(position);
	  }
	
	public void setHR(Double hr)
	{
		hrTextField.setText(hr.toString());
	} 
	
	
   /**
      The getName method returns the 
      name entered by the user.
      @return The name
    */
   
   public String getName()
   {
      return nameTextField.getText();
   }
   /**
      The getAddress method returns the 
      address entered by the user.
      @return The address
    */
   
   public String getPosition()
   {
      return positionTextField.getText();
   }
   
   /**
      The getHR method returns the 
      hourly rate entered by the user.
      @return the hourly rate
    */
   
   public Double getHR()
   {
	   //Since hourly rate is a number field, we have to check to see if something is in the text field
	   //before we parse the value as a double.  If nothing is in the field we return a null so we can use
	   //that null value during the sql query to determine if we need to search for the hourly rate
       if (hrTextField.getText().equals("")) {
    	   return null;
       } else {
    	    String getText = hrTextField.getText();
       		return Double.parseDouble(getText);
       }
   }
   
            
   /**
      The clear method sets each of the 
      text fields to an empty string.
    */

   
   public void clear()
   {
      nameTextField.setText("");
      positionTextField.setText("");
      hrTextField.setText("");
   }
}

