package databaseGUIUpdate;

import java.sql.*;

/**
   The userTableManager class provides methods for 
   inserting a record into the user table of the 
   testdbgui database.
*/

public class userTableManager
{
   // Create a named constant for the URL.
   // NOTE: This value is specific for Java DB
   public final String DB_URL = 
                "jdbc:ucanaccess://Personnel.accdb";

   // Field for the database connection
   private static Connection conn;

   /**
      Constructor
    */
   
   public userTableManager() throws SQLException
   {
      // Create a connection to the database.
      conn = DriverManager.getConnection(DB_URL);
   }
   
   //Creates method to select objects based on the search strings entered, hence the need for the
   //parameters that match what options they have to search with
   public static ResultSet selectUsers(String name, String position, Double hr) 
                      throws SQLException
   {
	   //Since we have a numerical value that cannot search correctly using the like command,
	   //this variable will be used to hold the sql statement if they entered a number to search
	   String addon;
	   
	   //If statement to see if the hr value passed is not null.  If so then a correct number was entered
	   //and the sql statement is created and put in the addon variable, otherwise addon is blank
	   if (hr != null) {
		   addon = " AND HourlyPay = ?";
	   } else {
		   addon = "";
	   }
	   
	   //Creates the SQL Statement, note the concatenation of the addon variable in case the user
	   //entered a number to search.  Not needed for the strings since the like command finds
	   //all results when the search field is blank.  Note the aliases to make the column names show nicely
	   //Also notice spaces after quotation marks so that the word AND does not run into field names
	   String ourSQLSelect = "SELECT EmployeeID as ID, EmployeeName as Name, EmployeePosition as Position,  "
					+ "HourlyPay as Rate from Employee where EmployeeName Like ?" + addon;  
                     
	   // Create a Statement object.
	   PreparedStatement prepStmt = conn.prepareStatement(ourSQLSelect);

	   //Statement to insert our variables into the prepared sql placeholders.  Number is the position
	   //that the question mark is at above, starting at one.  Variable types matter
	   prepStmt.setString(1, "%" + name + "%");
	   prepStmt.setString(2, "%" + position + "%");
	   
	   //Checks to see if the number value was null, if not then the addon sql command from above will be
	   //added and we will need to add the variable to the prepared placeholder
	   if (hr != null) {
		   prepStmt.setDouble(3, hr);
	   }

	   //Executes the query, note that the command is slightly different than select, due to the fact that
	   //no results are being returned
	   ResultSet userResults = prepStmt.executeQuery();
	  

	   return userResults;
   }
   

   	public static ResultSet selectUpdate(String userID) 
	           throws SQLException
	{
				
		//Creates the SQL Statement.  Note the aliases to make the column names show nicely
		//Also notice spaces after quotation marks so that the word AND does not run into field names
		String ourSQLSelect = "SELECT EmployeeID as EmployeeID, EmployeeName as Name, EmployeePosition as Position,  "
					+ "HourlyPay as Rate from Employee where EmployeeID = ?";  
		          
		// Create a Statement object.
		PreparedStatement prepStmt = conn.prepareStatement(ourSQLSelect);
		
		//Statement to insert our variables into the prepared sql placeholders.  Number is the position
		//that the question mark is at above, starting at one.  Variable types matter
		prepStmt.setString(1, userID);
		
		//Executes the query, note that the command is slightly different than select, due to the fact that
		//no results are being returned
		ResultSet userResults = prepStmt.executeQuery();
		
		
		return userResults;
	}
   	
   	public void updateRecord (String name, String position, double HR,
   				double userID) throws SQLException {
   		
   		String ourSQLUpdate = "update Employee set EmployeeName = ?, "
   				+ "EmployeePosition =  ?, HourlyPay = ?	WHERE EmployeeID = ?";
   		
   		// Create a Statement object.
   		PreparedStatement prepStmt = conn.prepareStatement(ourSQLUpdate);
	
		//Statement to insert our variables into the prepared sql placeholders.  Number is the position
		//that the question mark is at above, starting at one.  Variable types matter
		prepStmt.setString(1, name);
		prepStmt.setString(2, position);
		prepStmt.setDouble(3, HR);

		
		prepStmt.executeUpdate();
		prepStmt.close();
   	}
   	
   	
}