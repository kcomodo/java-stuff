package Ho_16_10;
import java.util.Scanner;
public class populationClass {

/* Quang Ho
 * 2/5/2021
 * Programming chapter 16 challenge 10
 *Write a program that will predict the size of a population
 * of organisms. The program should ask for the starting number of organisms,
 * their average daily population increase (as a percentage), and the number
 * of days they will multiply. Do not accept a number less than 2 for the starting
 * size of the population. Do not accept a negative number for average daily population
 * increase. Do not accept a number less than 1 for the number of days they will multiply.
 */
	public static void main(String[] args) {
		//Ask the user for 3 inputs
		//Starting population, amount of days, and daily percentage
		int startingPopulation;
		int AMOUNT_OF_DAYS;
		double daysMultiplied;
		Scanner scan  = new Scanner(System.in);
		System.out.println("Enter a starting population: ");
		startingPopulation = scan.nextInt();
		//If starting population is less than 2, take the user back to re-answer the question
		while(startingPopulation < 2) {
			System.out.println("Cannot have a population less than 2");
			System.out.println("Enter a starting population");
			startingPopulation = scan.nextInt();

		}
		//If the amount of days is less than 1, take the user back to re-answer the question
		System.out.println("Enter the amount of days to multiply: ");
		AMOUNT_OF_DAYS = scan.nextInt();
		while(AMOUNT_OF_DAYS < 1) {
			System.out.println("Cannot have a day less than 1");
			System.out.println("Enter the amount of days to multiply: ");
			AMOUNT_OF_DAYS = scan.nextInt();
		}
		//Ifthe percentage is negative, take the user back to re-answer the question
		System.out.println("Enter the average population increase: ");
		daysMultiplied = scan.nextDouble();
		while(daysMultiplied < 0) {
			System.out.println("Cannot be a negative number");
			System.out.println("Enter the average population increase: ");
			daysMultiplied = scan.nextDouble();
		}
		System.out.println(population(startingPopulation, AMOUNT_OF_DAYS, daysMultiplied));
		
	}
	//Using recursion to get the calculation
	//Calls for all 3 variables
	  public static double population(int numDays, int startingOrgan, double dailyPercentage) {
		  //Print out the first part of the day and the return it back to the method
	      if (numDays <= 1) {
	         System.out.print("Day: "+numDays + "\n " + startingOrgan +"\n");
	    
	         return startingOrgan;
	      } /*
	      Yesterday population will get the recursion for the methods called
	      Using yesterday population, we can get the amount of organism for today population 
	      Daily percentage will be divided by 100 
	      Return the class to be displayed
	      */ 
	      else {
	    
	         double yesterdayPopulation = population(numDays - 1, startingOrgan, dailyPercentage);
	         double todayPopulation = yesterdayPopulation + (yesterdayPopulation * dailyPercentage / 100);

	         System.out.print("Day: "+numDays + " \n" + todayPopulation + "\n");
	         return todayPopulation;
	      }
	  }

}
