package Ho_16_8;
import java.util.Scanner;
/*
 * Quang Ho
 * 1/28/2021
 * Sum of number using recursion
 * Create program that asks the user to enter a number
 * The program will then sum up all of the number that goes up to the number the user entered
 * Program requirement: Recursion
 */
public class sumOfNumberDemo {

	public static void main(String[] args) {
		//Import scanner and ask the user to enter a number
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number");
		int userInput = scanner.nextInt();
		//Create a new variable called numCount and call for the class sumOfNumber to use recursion
		int numCount = sumOfNumber.sum(userInput);
		//Print out the result
		System.out.println(numCount);
	}

}
