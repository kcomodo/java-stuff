import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class propertyTaxWindow extends JFrame{
	/*
	 * This program will create the GUI
	 * Panel needs to be created first
	 * Label will then be added onto the panel as well as the text field
	 * Button will be added lastly 
	 * Title will be property tax
	 * 
	 */
		private JPanel applicationPanel;
		private JLabel applicationLabel;
		private JTextField applicationTextField;
		private JButton calculateButton;
		
		private final String windowTitle = "Property Tax";
		//Create the panel
		//Add in a function to close the program 
		public propertyTaxWindow()
		{
			setTitle(windowTitle);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			buildPanel();
			add(applicationPanel);
			pack();
			setVisible(true);
		}
		//Display the panel with a message to ask the user for the property value
		//Add in a text field
		//Decided to make text field 15 to make it larger for the user
		//Add in actionlistener when user click on calculate
		private void buildPanel()
		{
			applicationLabel = new JLabel("Please enter the property\'s value");
			applicationTextField = new JTextField(15);
			calculateButton = new JButton("Calculate");
			calculateButton.addActionListener(new CalcButtonListener());
			applicationPanel = new JPanel();
			applicationPanel.add(applicationLabel);
			applicationPanel.add(applicationTextField);
			applicationPanel.add(calculateButton);
		}
		//Call for the property program to calculate the value the user has entered
		//Display the message using .showMessage from the JOption
		public class CalcButtonListener implements ActionListener
		{
			public void actionPerformed(ActionEvent e)
			{
				propertyTax property = new propertyTax(Double.parseDouble(applicationTextField.getText()));
				
				JOptionPane.showMessageDialog(null, "The assessment value: $" + property.getAssessmentValue() +
						"\nThe property tax: $" + property.getPropertyTax());
			}
		}
		
	}