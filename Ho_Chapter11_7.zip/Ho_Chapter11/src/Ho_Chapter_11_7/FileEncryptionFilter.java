package Ho_Chapter_11_7;
/*
 * Quang Ho
 * 10/15/2020
 * Chapter 11
 * Challenge 7
 * File Encryption Filter
 */
import java.io.IOException;

public class FileEncryptionFilter {
	/*
	 * Create a program that reads a file and modify it into a secret code
	 * Output the secret code onto a second file
	 */
	public static void main(String[] args) {
		System.out.print("We are encrypting your file");
		try {
			Crypto.encryptFile("MyLetters", "Encrypted.txt");
			System.out.println("All done, you are secure-ish");
		}
		catch (IOException e) {
			System.out.println("Error" + e.getMessage());
		}

	}

}
