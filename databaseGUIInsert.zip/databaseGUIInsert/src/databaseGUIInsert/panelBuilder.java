package databaseGUIInsert;

import javax.swing.*;
import java.awt.*;

/**
   The panelBuilder class builds a panel containing the 
   labels and text fields for inserting data into the user
   table of the testdbgui database.
*/

public class panelBuilder extends JPanel
{
	private JTextField numberTextField;
   private JTextField nameTextField;      // name
   private JTextField addressTextField;   // address
   private JTextField cityTextField;
   private JTextField stateTextField;
   private JTextField zipTextField;
 
   
   
   public panelBuilder()
   {
      // Create labels and text fields
      // for the user data.
	  JLabel numberPrompt = new JLabel("Customer Number");
	  numberTextField = new JTextField(45);
	  
      JLabel namePrompt = new JLabel("Customer Name");
      nameTextField = new JTextField(45);
      
      JLabel addressPrompt = new JLabel("Address");
      addressTextField = new JTextField(55);
      
   
      
      JLabel cityPrompt = new JLabel("City");
	  cityTextField = new JTextField(45);
	  
	  JLabel statePrompt = new JLabel("State");
	  stateTextField = new JTextField(45);
	  
	  JLabel zipPrompt = new JLabel("Zip");
	  zipTextField = new JTextField(9);
      
      // Create a grid layout manager 
      // with 12 rows and 1 column.
      setLayout(new GridLayout(12, 1));   
      setBorder(BorderFactory.createTitledBorder("Enter User Information"));
      
      // Add the labels and text fields
      // to the panel.
  
      
      add(numberPrompt);
      add(numberTextField);
      
      add(namePrompt);
      add(nameTextField);
      
      add(addressPrompt);
      add(addressTextField);
      
      add(cityPrompt);
      add(cityTextField);
      
      add(statePrompt);
      add(stateTextField);
      
      add(zipPrompt);
      add(zipTextField);
      
   
   }
   
      
   /**
      The getName method returns the 
      name entered by the user.
      @return The name
    */
 
   
   public int getNumber() {
	   String getText = numberTextField.getText();
	   return Integer.parseInt(getText);
   }
   public String getName()
   {
      return nameTextField.getText();
   }
   /**
      The getAddress method returns the 
      address entered by the user.
      @return The address
    */
   
   public String getAddress()
   {
      return addressTextField.getText();
   }

   public String getCity() {
	   return cityTextField.getText();
   }
   public String getState() {
	   return stateTextField.getText();
   }
   public String getZip() {
	   return zipTextField.getText();
   }
   

   
            
   /**
      The clear method sets each of the 
      text fields to an empty string.
    */
   
   public void clear()
   {
	  numberTextField.setText("");
      nameTextField.setText("");
      addressTextField.setText("");
      cityTextField.setText("");
      stateTextField.setText("");
      zipTextField.setText("");
  
   }
}
